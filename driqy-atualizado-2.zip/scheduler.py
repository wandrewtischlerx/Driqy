import os
from datetime import datetime

from apscheduler.schedulers.background import BackgroundScheduler


def purge_expired_posts(app, db, Post):
    """Apaga do banco (e do disco) todos os posts cujo tempo de vida acabou."""
    with app.app_context():
        now = datetime.utcnow()
        expired = Post.query.filter(Post.expires_at <= now).all()
        if not expired:
            return
        for post in expired:
            if post.media_filename:
                path = os.path.join(app.config["UPLOAD_FOLDER"], post.media_filename)
                if os.path.exists(path):
                    try:
                        os.remove(path)
                    except OSError:
                        pass
            db.session.delete(post)
        db.session.commit()
        app.logger.info(f"[scheduler] {len(expired)} post(s) expirado(s) removido(s).")


def start_scheduler(app, db, Post):
    scheduler = BackgroundScheduler(daemon=True)
    interval = app.config.get("CLEANUP_INTERVAL_SECONDS", 20)
    scheduler.add_job(
        func=lambda: purge_expired_posts(app, db, Post),
        trigger="interval",
        seconds=interval,
        id="purge_expired_posts",
        replace_existing=True,
    )
    scheduler.start()
    return scheduler
