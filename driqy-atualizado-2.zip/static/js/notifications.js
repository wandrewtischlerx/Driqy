(function () {
  // precisa ser capturado aqui, de forma síncrona: dentro do listener do
  // DOMContentLoaded, document.currentScript já não aponta mais para esta tag
  const scriptTag = document.currentScript;
  const POLL_MS = 5000;

  function setBadge(el, count) {
    if (!el) return;
    if (count > 0) {
      el.textContent = count > 99 ? "99+" : String(count);
      el.hidden = false;
    } else {
      el.hidden = true;
    }
  }

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, (c) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
    }[c]));
  }

  function iconFor(kind) {
    return kind === "like" ? "♥" : (kind === "comment" || kind === "reply") ? "💬" : "➕";
  }

  function panelItemHtml(n) {
    const avatar = n.actor_avatar
      ? '<img class="avatar-dot avatar-img" src="' + n.actor_avatar + '" alt="">'
      : '<span class="avatar-dot" style="background: linear-gradient(135deg, ' + n.actor_accent + ', var(--rose));">' + escapeHtml(n.actor_initial) + '</span>';
    return (
      '<a class="notif-item notif-panel-item ' + (n.is_read ? "" : "notif-unread") + '" href="' + n.target_url + '">' +
      '<span class="notif-icon notif-icon-' + n.kind + '" aria-hidden="true">' + iconFor(n.kind) + '</span>' +
      avatar +
      '<span class="notif-body">' +
      '<span><strong>' + escapeHtml(n.actor_name) + '</strong> ' + escapeHtml(n.verb) + '</span>' +
      (n.snippet ? '<span class="notif-snippet">\u201c' + escapeHtml(n.snippet) + '\u201d</span>' : "") +
      '<span class="notif-meta">' + n.created_at + ' UTC</span>' +
      '</span></a>'
    );
  }

  function fullListItemHtml(n) {
    const avatar = n.actor_avatar
      ? '<img class="avatar-dot avatar-img" src="' + n.actor_avatar + '" alt="">'
      : '<span class="avatar-dot" style="background: linear-gradient(135deg, ' + n.actor_accent + ', var(--rose));">' + escapeHtml(n.actor_initial) + '</span>';
    return (
      '<a class="notif-item notif-unread notif-just-arrived" data-notif-id="' + n.id + '" href="' + n.target_url + '">' +
      '<span class="notif-icon notif-icon-' + n.kind + '" aria-hidden="true">' + iconFor(n.kind) + '</span>' +
      avatar +
      '<span class="notif-body">' +
      '<span><strong>' + escapeHtml(n.actor_name) + '</strong> ' + escapeHtml(n.verb) + '</span>' +
      (n.snippet ? '<span class="notif-snippet">\u201c' + escapeHtml(n.snippet) + '\u201d</span>' : "") +
      '<span class="notif-meta">' + n.created_at + ' UTC</span>' +
      '</span></a>'
    );
  }

  document.addEventListener("DOMContentLoaded", () => {
    const countUrl = scriptTag && scriptTag.dataset.countUrl;
    const recentUrl = scriptTag && scriptTag.dataset.recentUrl;
    const pageUrl = scriptTag && scriptTag.dataset.pageUrl;
    if (!countUrl) return;

    const bellBtn = document.getElementById("notif-bell-btn");
    const panel = document.getElementById("notif-panel");
    const panelList = document.getElementById("notif-panel-list");
    const notifWrap = document.getElementById("notif-wrap");

    function pollBadge() {
      fetch(countUrl, { headers: { "X-Requested-With": "fetch" } })
        .then((res) => (res.ok ? res.json() : null))
        .then((data) => {
          if (!data) return;
          setBadge(document.getElementById("notif-badge"), data.unread);
          setBadge(document.getElementById("notif-badge-sidebar"), data.unread);
        })
        .catch(() => {});
    }

    function loadPanel() {
      if (!recentUrl || !panelList) return;
      fetch(recentUrl, { headers: { "X-Requested-With": "fetch" } })
        .then((res) => (res.ok ? res.json() : null))
        .then((data) => {
          if (!data) return;
          const items = data.notifications || [];
          panelList.innerHTML = items.length
            ? items.map(panelItemHtml).join("")
            : '<p class="hint notif-panel-empty">Nada por aqui ainda.</p>';
        })
        .catch(() => {
          panelList.innerHTML = '<p class="hint notif-panel-empty">Não foi possível carregar agora.</p>';
        });
    }

    if (bellBtn && panel) {
      bellBtn.addEventListener("click", (event) => {
        event.stopPropagation();
        if (window.driqySettings && !window.driqySettings.panelEnabled() && pageUrl) {
          window.location.href = pageUrl;
          return;
        }
        const isHidden = panel.hidden;
        panel.hidden = !isHidden;
        bellBtn.setAttribute("aria-expanded", String(isHidden));
        if (isHidden) loadPanel();
      });

      document.addEventListener("click", (event) => {
        if (notifWrap && !notifWrap.contains(event.target)) {
          panel.hidden = true;
          bellBtn.setAttribute("aria-expanded", "false");
        }
      });

      document.addEventListener("keydown", (event) => {
        if (event.key === "Escape") {
          panel.hidden = true;
          bellBtn.setAttribute("aria-expanded", "false");
        }
      });
    }

    // ---------- Página de notificações: atualização ao vivo, sem recarregar ----------
    const notifList = document.getElementById("notif-list");
    let lastSeenId = notifList ? parseInt(notifList.dataset.lastId || "0", 10) : 0;

    function pollLiveNotifications() {
      if (!notifList || !recentUrl) return;
      fetch(recentUrl + "?since_id=" + lastSeenId, { headers: { "X-Requested-With": "fetch" } })
        .then((res) => (res.ok ? res.json() : null))
        .then((data) => {
          if (!data || !data.notifications || !data.notifications.length) return;
          const emptyState = document.querySelector(".notif-empty-state");
          if (emptyState) emptyState.remove();
          const ordered = data.notifications.slice().reverse();
          ordered.forEach((n) => {
            if (n.id > lastSeenId) lastSeenId = n.id;
            notifList.insertAdjacentHTML("afterbegin", fullListItemHtml(n));
          });
          notifList.dataset.lastId = String(lastSeenId);
          if (window.driqySettings) window.driqySettings.playNotifSound();
        })
        .catch(() => {});
    }

    pollBadge();
    setInterval(() => {
      pollBadge();
      pollLiveNotifications();
      if (panel && !panel.hidden && window.driqySettings && window.driqySettings.panelEnabled()) loadPanel();
    }, POLL_MS);
  });
})();
