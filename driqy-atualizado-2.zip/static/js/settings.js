(function () {
  const THEME_KEY = "driqy-theme";
  const SOUND_KEY = "driqy-notif-sound";
  const PANEL_KEY = "driqy-notif-panel";

  function applyTheme(key) {
    document.documentElement.setAttribute("data-theme", key);
    try { localStorage.setItem(THEME_KEY, key); } catch (e) {}
    document.querySelectorAll(".theme-option").forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.themeKey === key);
    });
  }

  function readBool(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw === null ? fallback : raw === "1";
    } catch (e) {
      return fallback;
    }
  }

  function writeBool(key, value) {
    try { localStorage.setItem(key, value ? "1" : "0"); } catch (e) {}
  }

  // Um único AudioContext reaproveitado — criar um novo a cada aviso faz o
  // navegador aplicar a política de autoplay e suspender o contexto sempre
  // que a chamada não vier de um gesto do usuário (como acontece durante o
  // polling em segundo plano), silenciando o som "em tempo real".
  let audioCtx = null;
  function getAudioContext() {
    if (!audioCtx) {
      try {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      } catch (e) {
        return null;
      }
    }
    return audioCtx;
  }

  // Qualquer interação do usuário destrava/retoma o contexto, para que os
  // avisos futuros disparados pelo polling automático já toquem sem precisar
  // de um novo gesto.
  ["pointerdown", "keydown"].forEach((evt) => {
    document.addEventListener(evt, () => {
      const ctx = getAudioContext();
      if (ctx && ctx.state === "suspended") ctx.resume().catch(() => {});
    }, { passive: true });
  });

  // Exposto para notifications.js / chat.js consultarem as preferências do usuário.
  window.driqySettings = {
    soundEnabled: () => readBool(SOUND_KEY, false),
    panelEnabled: () => readBool(PANEL_KEY, true),
    playNotifSound: function () {
      if (!this.soundEnabled()) return;
      const ctx = getAudioContext();
      if (!ctx) return;
      const beep = () => {
        try {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = "sine";
          osc.frequency.value = 720;
          gain.gain.setValueAtTime(0.001, ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.12, ctx.currentTime + 0.02);
          gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.28);
          osc.connect(gain).connect(ctx.destination);
          osc.start();
          osc.stop(ctx.currentTime + 0.3);
        } catch (e) {}
      };
      if (ctx.state === "suspended") {
        ctx.resume().then(beep).catch(() => {});
      } else {
        beep();
      }
    },
  };

  document.addEventListener("DOMContentLoaded", () => {
    const current = document.documentElement.getAttribute("data-theme") || "dark";
    applyTheme(current);

    document.querySelectorAll(".theme-option").forEach((btn) => {
      btn.addEventListener("click", () => applyTheme(btn.dataset.themeKey));
    });

    // ---------- Painel de configurações (modal) ----------
    const openBtn = document.getElementById("settings-open-btn");
    const modal = document.getElementById("settings-modal");
    const overlay = document.getElementById("settings-overlay");
    const closeBtn = document.getElementById("settings-close");
    const soundToggle = document.getElementById("setting-sound");
    const panelToggle = document.getElementById("setting-panel");

    if (soundToggle) soundToggle.checked = readBool(SOUND_KEY, false);
    if (panelToggle) panelToggle.checked = readBool(PANEL_KEY, true);

    if (soundToggle) {
      soundToggle.addEventListener("change", () => {
        writeBool(SOUND_KEY, soundToggle.checked);
        if (soundToggle.checked) window.driqySettings.playNotifSound();
      });
    }
    if (panelToggle) {
      panelToggle.addEventListener("change", () => writeBool(PANEL_KEY, panelToggle.checked));
    }

    if (openBtn && modal && overlay) {
      const openModal = () => {
        modal.hidden = false;
        overlay.hidden = false;
        document.body.style.overflow = "hidden";
        // fecha a sidebar por trás, se estiver aberta
        const sidebar = document.getElementById("sidebar");
        const sidebarOverlay = document.getElementById("sidebar-overlay");
        if (sidebar) sidebar.classList.remove("open");
        if (sidebarOverlay) sidebarOverlay.classList.remove("open");
      };
      const closeModal = () => {
        modal.hidden = true;
        overlay.hidden = true;
        document.body.style.overflow = "";
      };

      openBtn.addEventListener("click", openModal);
      overlay.addEventListener("click", closeModal);
      if (closeBtn) closeBtn.addEventListener("click", closeModal);
      document.addEventListener("keydown", (event) => {
        if (event.key === "Escape" && !modal.hidden) closeModal();
      });
    }
  });
})();
