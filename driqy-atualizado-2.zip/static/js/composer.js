/*
 * Caixa de publicação rápida no topo do feed ("O que está acontecendo?").
 * Cuida de: auto-crescer o textarea, anexar mídia com prévia (detectando o
 * tipo do post pela extensão do arquivo), escolher GIF, escolher a duração
 * do post (com um painel fluido de abrir/fechar) e habilitar o botão de
 * postar só quando há conteúdo válido. Anexar uma mídia apenas mostra a
 * prévia — o post só é publicado quando a pessoa clica em "Postar".
 */
(function () {
  document.addEventListener("DOMContentLoaded", () => {
    const card = document.getElementById("composer");
    if (!card) return; // página sem composer (ex: usuário não logado)

    const form = document.getElementById("composer-form");
    const textArea = document.getElementById("composer-text");
    const postTypeInput = document.getElementById("composer-post-type");
    const durationInput = document.getElementById("composer-duration-input");
    const durationLabel = document.getElementById("composer-duration-label");
    const durationBtn = document.getElementById("composer-duration-btn");
    const durationPanel = document.getElementById("composer-duration-panel");
    const postBtn = document.getElementById("composer-post-btn");
    const charCount = document.getElementById("composer-char-count");

    const mediaBtn = document.getElementById("composer-media-btn");
    const mediaFileInput = document.getElementById("composer-media-file");
    const gifBtn = document.getElementById("composer-gif-btn");
    const gifFileInput = document.getElementById("composer-gif-file");

    const mediaPreview = document.getElementById("composer-media-preview");
    const mediaImg = document.getElementById("composer-media-img");
    const mediaVideo = document.getElementById("composer-media-video");
    const mediaRemoveBtn = document.getElementById("composer-media-remove");

    const VIDEO_EXT = ["mp4", "webm", "mov"];
    let attachedObjectUrl = null;
    let hasMedia = false;

    // ---------- Textarea que cresce sozinho ----------
    function autoGrow() {
      textArea.style.height = "auto";
      textArea.style.height = textArea.scrollHeight + "px";
    }

    function updatePostState() {
      const hasText = textArea.value.trim().length > 0;
      postBtn.disabled = !(hasText || hasMedia);

      const len = textArea.value.length;
      if (len > 800) {
        charCount.hidden = false;
        charCount.textContent = (1000 - len).toString();
        charCount.classList.toggle("warn", len >= 1000);
      } else {
        charCount.hidden = true;
      }
    }

    textArea.addEventListener("input", () => {
      autoGrow();
      updatePostState();
    });

    // ---------- Painel de duração (fluido: abre/fecha com transição) ----------
    function closeDurationPanel() {
      if (!durationPanel) return;
      durationPanel.classList.remove("open");
      durationPanel.setAttribute("aria-hidden", "true");
      if (durationBtn) durationBtn.setAttribute("aria-expanded", "false");
    }

    function toggleDurationPanel() {
      if (!durationPanel) return;
      const willOpen = !durationPanel.classList.contains("open");
      durationPanel.classList.toggle("open", willOpen);
      durationPanel.setAttribute("aria-hidden", willOpen ? "false" : "true");
      if (durationBtn) durationBtn.setAttribute("aria-expanded", willOpen ? "true" : "false");
    }

    document.addEventListener("click", (e) => {
      if (!card.contains(e.target)) closeDurationPanel();
    });

    // ---------- Anexar mídia (foto ou vídeo) ----------
    function detectPostType(filename) {
      const ext = filename.split(".").pop().toLowerCase();
      if (ext === "gif") return "gif";
      if (VIDEO_EXT.includes(ext)) return "video";
      return "photo";
    }

    function showMediaPreview(file) {
      if (attachedObjectUrl) URL.revokeObjectURL(attachedObjectUrl);
      attachedObjectUrl = URL.createObjectURL(file);

      const type = detectPostType(file.name);
      postTypeInput.value = type;

      if (type === "video") {
        mediaVideo.src = attachedObjectUrl;
        mediaVideo.hidden = false;
        mediaImg.hidden = true;
      } else {
        mediaImg.src = attachedObjectUrl;
        mediaImg.hidden = false;
        mediaVideo.hidden = true;
      }

      mediaPreview.hidden = false;
      hasMedia = true;
      updatePostState();
      return type;
    }

    function clearMedia() {
      mediaFileInput.value = "";
      gifFileInput.value = "";
      if (attachedObjectUrl) {
        URL.revokeObjectURL(attachedObjectUrl);
        attachedObjectUrl = null;
      }
      mediaImg.removeAttribute("src");
      mediaVideo.removeAttribute("src");
      mediaPreview.hidden = true;
      postTypeInput.value = "text";
      hasMedia = false;
      updatePostState();
    }

    if (mediaBtn) {
      mediaBtn.addEventListener("click", () => mediaFileInput.click());
    }
    mediaFileInput.addEventListener("change", () => {
      const file = mediaFileInput.files && mediaFileInput.files[0];
      if (!file) return;
      gifFileInput.value = "";
      // Só mostra a prévia; a publicação só acontece quando a pessoa
      // clicar em "Postar" (antes disso, dava pra revisar/remover a mídia).
      showMediaPreview(file);
    });

    if (gifBtn) {
      gifBtn.addEventListener("click", () => gifFileInput.click());
    }
    gifFileInput.addEventListener("change", () => {
      const file = gifFileInput.files && gifFileInput.files[0];
      if (!file) return;
      mediaFileInput.value = "";
      // O input "de verdade" enviado no form é o de mídia geral, então
      // transferimos o GIF escolhido pra ele antes de enviar.
      const dt = new DataTransfer();
      dt.items.add(file);
      mediaFileInput.files = dt.files;
      showMediaPreview(file);
    });

    mediaRemoveBtn.addEventListener("click", clearMedia);

    // ---------- Duração ----------
    if (durationBtn && durationPanel) {
      durationBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        toggleDurationPanel();
      });
      durationPanel.addEventListener("click", (e) => {
        const btn = e.target.closest(".composer-duration-opt");
        if (!btn) return;
        durationPanel.querySelectorAll(".composer-duration-opt").forEach((b) => b.classList.remove("selected"));
        btn.classList.add("selected");
        durationInput.value = btn.dataset.minutes;
        durationLabel.textContent = "Some em " + btn.textContent.toLowerCase();
        closeDurationPanel();
      });
    }

    form.addEventListener("submit", () => {
      postBtn.disabled = true;
      postBtn.textContent = "Publicando…";
    });

    updatePostState();
  });
})();
