(function () {
  const RADIUS = 17;
  const CIRCUMFERENCE = 2 * Math.PI * RADIUS;

  function formatRemaining(totalSeconds) {
    if (totalSeconds <= 0) return "0s";
    const days = Math.floor(totalSeconds / 86400);
    const hours = Math.floor((totalSeconds % 86400) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = Math.floor(totalSeconds % 60);

    if (days > 0) return `${days}d`;
    if (hours > 0) return `${hours}h`;
    if (minutes > 0) return `${minutes}m`;
    return `${seconds}s`;
  }

  function formatElapsed(totalSeconds) {
    const seconds = Math.max(0, Math.floor(totalSeconds));
    if (seconds < 45) return "agora";
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `há ${minutes} min`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `há ${hours}h`;
    const days = Math.floor(hours / 24);
    if (days < 7) return `há ${days}d`;
    const weeks = Math.floor(days / 7);
    return `há ${weeks} sem`;
  }

  function tickElapsedLabels() {
    document.querySelectorAll(".post-elapsed[data-created]").forEach((el) => {
      const created = new Date(el.dataset.created).getTime();
      if (Number.isNaN(created)) return;
      const elapsedSeconds = (Date.now() - created) / 1000;
      el.textContent = formatElapsed(elapsedSeconds);
    });
  }

  function tickCard(card) {
    const expiresAt = new Date(card.dataset.expires).getTime();
    const totalSeconds = parseFloat(card.dataset.duration);
    const now = Date.now();
    const remainingMs = expiresAt - now;
    const remainingSeconds = Math.max(0, remainingMs / 1000);

    const wrap = card.querySelector(".countdown-ring-wrap");
    const ring = card.querySelector(".countdown-ring-fg");
    const label = card.querySelector(".countdown-label");

    const fraction = totalSeconds > 0 ? Math.max(0, Math.min(1, remainingSeconds / totalSeconds)) : 0;

    if (ring) {
      const offset = CIRCUMFERENCE * (1 - fraction);
      ring.style.strokeDasharray = `${CIRCUMFERENCE}`;
      ring.style.strokeDashoffset = `${offset}`;
    }
    if (label) {
      label.textContent = formatRemaining(remainingSeconds);
    }
    if (wrap) {
      wrap.classList.toggle("countdown-ring-urgent", fraction <= 0.1 && remainingSeconds > 0);
    }

    if (remainingSeconds <= 0) {
      card.classList.add("post-expiring");
      setTimeout(() => {
        card.style.transition = "opacity .6s ease, max-height .6s ease, margin .6s ease, padding .6s ease";
        card.style.opacity = "0";
        card.style.maxHeight = card.offsetHeight + "px";
        requestAnimationFrame(() => {
          card.style.maxHeight = "0px";
          card.style.margin = "0";
          card.style.padding = "0";
          card.style.overflow = "hidden";
        });
        setTimeout(() => card.remove(), 650);
      }, 400);
      return false; // para de atualizar este card
    }
    return true;
  }

  const active = new Set();
  let intervalStarted = false;

  function ensureInterval() {
    if (intervalStarted) return;
    intervalStarted = true;
    setInterval(() => {
      active.forEach((card) => {
        if (!document.body.contains(card)) {
          active.delete(card);
          return;
        }
        const stillActive = tickCard(card);
        if (!stillActive) active.delete(card);
      });
    }, 1000);
  }

  function registerCard(card) {
    if (!card || active.has(card)) return;
    active.add(card);
    tickCard(card);
    ensureInterval();
  }

  function startCountdowns() {
    tickElapsedLabels();
    setInterval(tickElapsedLabels, 30000);

    document.querySelectorAll(".post-card[data-expires]").forEach(registerCard);
  }

  window.driqyCountdown = { registerCard, tickElapsedLabels };

  document.addEventListener("DOMContentLoaded", startCountdowns);

  document.addEventListener("click", (event) => {
    const openLink = event.target.closest(".post-open-link");
    if (openLink) {
      // Não navega se o clique foi em algo interativo dentro do post
      // (menção @usuario, vídeo com controles, seleção de texto, etc.)
      const interactive = event.target.closest("a, button, video, input, textarea");
      const isSelecting = window.getSelection && String(window.getSelection()).length > 0;
      if (!interactive && !isSelecting) {
        window.location.href = openLink.dataset.href;
      }
      return;
    }

    const btn = event.target.closest(".comment-toggle");
    if (btn) {
      const target = document.getElementById(btn.dataset.target);
      if (target) target.hidden = !target.hidden;
      return;
    }

    const replyBtn = event.target.closest(".comment-reply-toggle");
    if (replyBtn) {
      const target = document.getElementById(replyBtn.dataset.target);
      if (target) {
        target.hidden = !target.hidden;
        if (!target.hidden) {
          const input = target.querySelector("input[type=text]");
          if (input) {
            input.focus();
            const len = input.value.length;
            input.setSelectionRange(len, len);
          }
        }
      }
      return;
    }

    const shareBtn = event.target.closest(".share-btn");
    if (shareBtn) {
      const url = shareBtn.dataset.shareUrl;
      if (!url) return;

      const showFeedback = (text, ok) => {
        shareBtn.classList.add("share-btn-done");
        shareBtn.setAttribute("title", text);
        clearTimeout(shareBtn._feedbackTimeout);
        shareBtn._feedbackTimeout = setTimeout(() => {
          shareBtn.classList.remove("share-btn-done");
          shareBtn.setAttribute("title", "Copiar link deste post");
        }, 1800);
      };

      if (navigator.share) {
        navigator.share({ url }).catch(() => {});
        return;
      }

      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(url)
          .then(() => showFeedback("✓ Link copiado!"))
          .catch(() => showFeedback("Não foi possível copiar"));
      } else {
        const helper = document.createElement("textarea");
        helper.value = url;
        helper.style.position = "fixed";
        helper.style.opacity = "0";
        document.body.appendChild(helper);
        helper.select();
        try {
          document.execCommand("copy");
          showFeedback("✓ Link copiado!");
        } catch (e) {
          showFeedback("Não foi possível copiar");
        }
        document.body.removeChild(helper);
      }
    }
  });
})();
