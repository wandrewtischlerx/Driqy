import os
from datetime import datetime
from functools import wraps

from flask import (
    Blueprint, render_template, redirect, url_for, flash, request,
    current_app, abort
)
from flask_login import login_required, current_user

from extensions import db
from models import User, Post, Follow

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")


def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            abort(403)
        return f(*args, **kwargs)
    return wrapper


def staff_required(f):
    """Permite acesso a administradores e também a moderadores."""
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_staff:
            abort(403)
        return f(*args, **kwargs)
    return wrapper


@admin_bp.route("/")
@login_required
@admin_required
def dashboard():
    from datetime import timedelta
    from models import Comment
    now = datetime.utcnow()
    week_ago = now - timedelta(days=7)

    posts_by_type = dict(
        db.session.query(Post.post_type, db.func.count(Post.id))
        .group_by(Post.post_type).all()
    )

    stats = {
        "total_users": User.query.count(),
        "banned_users": User.query.filter_by(is_banned=True).count(),
        "admins": User.query.filter_by(is_admin=True).count(),
        "moderators": User.query.filter_by(is_moderator=True).count(),
        "verified_users": User.query.filter_by(is_verified=True).count(),
        "new_users_7d": User.query.filter(User.created_at >= week_ago).count(),
        "active_posts": Post.query.filter(Post.expires_at > now).count(),
        "expired_posts": Post.query.filter(Post.expires_at <= now).count(),
        "posts_7d": Post.query.filter(Post.created_at >= week_ago).count(),
        "total_follows": Follow.query.count(),
        "total_likes": db.session.query(db.func.coalesce(db.func.sum(User.total_likes_received), 0)).scalar(),
        "total_comments": Comment.query.count(),
        "posts_text": posts_by_type.get("text", 0),
        "posts_photo": posts_by_type.get("photo", 0),
        "posts_video": posts_by_type.get("video", 0),
        "posts_gif": posts_by_type.get("gif", 0),
    }
    latest_users = User.query.order_by(User.created_at.desc()).limit(5).all()
    latest_posts = Post.query.order_by(Post.created_at.desc()).limit(5).all()
    top_ranked = sorted(
        User.query.filter_by(is_banned=False).all(),
        key=lambda u: u.ranking_score, reverse=True
    )[:5]
    return render_template(
        "admin/dashboard.html", stats=stats,
        latest_users=latest_users, latest_posts=latest_posts, top_ranked=top_ranked,
    )


@admin_bp.route("/usuarios")
@login_required
@staff_required
def users():
    q = request.args.get("q", "").strip()
    page = request.args.get("page", 1, type=int)
    query = User.query
    if q:
        query = query.filter(
            (User.username.ilike(f"%{q}%")) | (User.email.ilike(f"%{q}%"))
        )
    pagination = query.order_by(User.created_at.desc()).paginate(
        page=page, per_page=20, error_out=False
    )
    return render_template("admin/users.html", pagination=pagination, q=q)


@admin_bp.route("/usuarios/<int:user_id>/banir", methods=["POST"])
@login_required
@staff_required
def ban_user(user_id):
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash("Você não pode banir a si mesmo.", "danger")
        return redirect(url_for("admin.users"))
    if (user.is_admin or user.is_moderator) and not current_user.is_admin:
        flash("Apenas administradores podem banir outros membros da equipe.", "danger")
        return redirect(url_for("admin.users"))
    user.is_banned = True
    db.session.commit()
    flash(f"Usuário @{user.username} foi banido.", "warning")
    return redirect(url_for("admin.users"))


@admin_bp.route("/usuarios/<int:user_id>/desbanir", methods=["POST"])
@login_required
@staff_required
def unban_user(user_id):
    user = User.query.get_or_404(user_id)
    user.is_banned = False
    db.session.commit()
    flash(f"Usuário @{user.username} foi desbanido.", "success")
    return redirect(url_for("admin.users"))


@admin_bp.route("/usuarios/<int:user_id>/tornar-admin", methods=["POST"])
@login_required
@admin_required
def make_admin(user_id):
    user = User.query.get_or_404(user_id)
    user.is_admin = True
    db.session.commit()
    flash(f"@{user.username} agora é administrador.", "success")
    return redirect(url_for("admin.users"))


@admin_bp.route("/usuarios/<int:user_id>/remover-admin", methods=["POST"])
@login_required
@admin_required
def remove_admin(user_id):
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash("Você não pode remover seu próprio acesso de administrador.", "danger")
        return redirect(url_for("admin.users"))
    user.is_admin = False
    db.session.commit()
    flash(f"Privilégios de administrador removidos de @{user.username}.", "info")
    return redirect(url_for("admin.users"))


@admin_bp.route("/usuarios/<int:user_id>/tornar-moderador", methods=["POST"])
@login_required
@admin_required
def make_moderator(user_id):
    user = User.query.get_or_404(user_id)
    if user.is_admin:
        flash(f"@{user.username} já é administrador.", "info")
        return redirect(url_for("admin.users"))
    user.is_moderator = True
    db.session.commit()
    flash(f"@{user.username} agora é moderador(a).", "success")
    return redirect(url_for("admin.users"))


@admin_bp.route("/usuarios/<int:user_id>/remover-moderador", methods=["POST"])
@login_required
@admin_required
def remove_moderator(user_id):
    user = User.query.get_or_404(user_id)
    user.is_moderator = False
    db.session.commit()
    flash(f"Privilégios de moderador removidos de @{user.username}.", "info")
    return redirect(url_for("admin.users"))


@admin_bp.route("/usuarios/<int:user_id>/verificar", methods=["POST"])
@login_required
@admin_required
def verify_user(user_id):
    user = User.query.get_or_404(user_id)
    user.is_verified = True
    db.session.commit()
    flash(f"@{user.username} agora é uma conta verificada.", "success")
    return redirect(request.referrer or url_for("admin.users"))


@admin_bp.route("/usuarios/<int:user_id>/remover-verificacao", methods=["POST"])
@login_required
@admin_required
def unverify_user(user_id):
    user = User.query.get_or_404(user_id)
    user.is_verified = False
    db.session.commit()
    flash(f"Selo de verificação removido de @{user.username}.", "info")
    return redirect(request.referrer or url_for("admin.users"))


@admin_bp.route("/usuarios/<int:user_id>/excluir", methods=["POST"])
@login_required
@admin_required
def delete_user(user_id):
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash("Você não pode excluir sua própria conta por aqui.", "danger")
        return redirect(url_for("admin.users"))

    # remove arquivos de mídia dos posts do usuário
    for post in user.posts:
        _delete_media_file(post)

    Follow.query.filter(
        (Follow.follower_id == user.id) | (Follow.followed_id == user.id)
    ).delete()

    db.session.delete(user)
    db.session.commit()
    flash(f"Conta @{user.username} excluída permanentemente.", "warning")
    return redirect(url_for("admin.users"))


@admin_bp.route("/posts")
@login_required
@staff_required
def posts():
    page = request.args.get("page", 1, type=int)
    pagination = Post.query.order_by(Post.created_at.desc()).paginate(
        page=page, per_page=25, error_out=False
    )
    return render_template("admin/posts.html", pagination=pagination)


@admin_bp.route("/posts/<int:post_id>/excluir", methods=["POST"])
@login_required
@staff_required
def delete_post(post_id):
    post = Post.query.get_or_404(post_id)
    _delete_media_file(post)
    db.session.delete(post)
    db.session.commit()
    flash("Post removido pela moderação.", "warning")
    return redirect(request.referrer or url_for("admin.posts"))


@admin_bp.route("/comentarios/<int:comment_id>/excluir", methods=["POST"])
@login_required
@staff_required
def delete_comment(comment_id):
    from models import Comment
    comment = Comment.query.get_or_404(comment_id)
    for reply in list(comment.replies):
        db.session.delete(reply)
    db.session.delete(comment)
    db.session.commit()
    flash("Comentário removido pela moderação.", "warning")
    return redirect(request.referrer or url_for("admin.posts"))


def _delete_media_file(post):
    if post.media_filename:
        path = os.path.join(current_app.config["UPLOAD_FOLDER"], post.media_filename)
        if os.path.exists(path):
            try:
                os.remove(path)
            except OSError:
                pass
