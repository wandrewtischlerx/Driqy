from datetime import datetime

from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify, abort
from flask_login import login_required, current_user
from sqlalchemy import or_, and_, func

from extensions import db
from models import User, Message

chat_bp = Blueprint("chat", __name__, url_prefix="/mensagens")


def _partner_ids_for(user_id):
    """IDs de todo mundo com quem `user_id` já trocou pelo menos uma mensagem."""
    sent_to = db.session.query(Message.recipient_id).filter(Message.sender_id == user_id)
    received_from = db.session.query(Message.sender_id).filter(Message.recipient_id == user_id)
    ids = {row[0] for row in sent_to.union(received_from).all()}
    ids.discard(user_id)
    return ids


def _conversation_query(user_a_id, user_b_id):
    return Message.query.filter(
        or_(
            and_(Message.sender_id == user_a_id, Message.recipient_id == user_b_id),
            and_(Message.sender_id == user_b_id, Message.recipient_id == user_a_id),
        )
    )


@chat_bp.route("/")
@login_required
def inbox():
    """Lista de conversas, ordenada pela mensagem mais recente em cada uma."""
    partner_ids = _partner_ids_for(current_user.id)
    conversations = []

    if partner_ids:
        partners = User.query.filter(User.id.in_(partner_ids)).all()
        for partner in partners:
            last_msg = (
                _conversation_query(current_user.id, partner.id)
                .order_by(Message.created_at.desc())
                .first()
            )
            unread = _conversation_query(partner.id, current_user.id).filter(
                Message.sender_id == partner.id, Message.is_read.is_(False)
            ).count()
            conversations.append({
                "partner": partner,
                "last_message": last_msg,
                "unread": unread,
            })
        conversations.sort(
            key=lambda c: c["last_message"].created_at if c["last_message"] else datetime.min,
            reverse=True,
        )

    return render_template("messages_inbox.html", conversations=conversations)


@chat_bp.route("/<username>")
@login_required
def thread(username):
    partner = User.query.filter_by(username=username).first_or_404()
    if partner.id == current_user.id:
        flash("Você não pode enviar mensagens para si mesmo.", "info")
        return redirect(url_for("chat.inbox"))

    messages = (
        _conversation_query(current_user.id, partner.id)
        .order_by(Message.created_at.asc())
        .all()
    )

    # marca como lidas as mensagens que o parceiro enviou para mim
    unread_ids = [m.id for m in messages if m.recipient_id == current_user.id and not m.is_read]
    if unread_ids:
        Message.query.filter(Message.id.in_(unread_ids)).update(
            {"is_read": True}, synchronize_session=False
        )
        db.session.commit()

    last_id = messages[-1].id if messages else 0
    return render_template("messages_thread.html", partner=partner, messages=messages, last_id=last_id)


@chat_bp.route("/<username>/enviar", methods=["POST"])
@login_required
def send(username):
    partner = User.query.filter_by(username=username).first_or_404()
    if partner.id == current_user.id:
        abort(400)

    content = (request.form.get("content") or "").strip()
    is_fetch = request.headers.get("X-Requested-With") == "fetch"

    if not content:
        if is_fetch:
            return jsonify({"error": "Escreva algo antes de enviar."}), 400
        flash("Escreva algo antes de enviar.", "danger")
        return redirect(url_for("chat.thread", username=username))

    if len(content) > 2000:
        content = content[:2000]

    msg = Message(sender_id=current_user.id, recipient_id=partner.id, content=content)
    db.session.add(msg)
    db.session.commit()

    if is_fetch:
        return jsonify({
            "message": {
                "id": msg.id,
                "content": msg.content,
                "sender_id": msg.sender_id,
                "created_at": msg.created_at.strftime("%d/%m/%Y %H:%M"),
                "mine": True,
            }
        })

    return redirect(url_for("chat.thread", username=username))


@chat_bp.route("/api/<username>/novas")
@login_required
def poll_new(username):
    """Usado pelo front-end do chat para buscar mensagens novas sem recarregar a página."""
    partner = User.query.filter_by(username=username).first_or_404()
    since_id = request.args.get("since_id", 0, type=int)

    new_messages = (
        _conversation_query(current_user.id, partner.id)
        .filter(Message.id > since_id)
        .order_by(Message.created_at.asc())
        .all()
    )

    unread_ids = [m.id for m in new_messages if m.recipient_id == current_user.id and not m.is_read]
    if unread_ids:
        Message.query.filter(Message.id.in_(unread_ids)).update(
            {"is_read": True}, synchronize_session=False
        )
        db.session.commit()

    return jsonify({
        "messages": [
            {
                "id": m.id,
                "content": m.content,
                "sender_id": m.sender_id,
                "created_at": m.created_at.strftime("%d/%m/%Y %H:%M"),
                "mine": m.sender_id == current_user.id,
            }
            for m in new_messages
        ]
    })


@chat_bp.route("/api/contagem")
@login_required
def unread_count():
    """Usado pelo ícone de mensagens no topo, igual ao sino de notificações."""
    return jsonify({"unread": current_user.unread_messages_count})


@chat_bp.route("/api/atualizacoes")
@login_required
def inbox_updates():
    """Usado pela caixa de entrada para atualizar prévias/contadores sem recarregar."""
    partner_ids = _partner_ids_for(current_user.id)
    data = []
    conversations = []
    for partner_id in partner_ids:
        last_msg = (
            _conversation_query(current_user.id, partner_id)
            .order_by(Message.created_at.desc())
            .first()
        )
        if not last_msg:
            continue
        unread = _conversation_query(partner_id, current_user.id).filter(
            Message.sender_id == partner_id, Message.is_read.is_(False)
        ).count()
        partner = User.query.get(partner_id)
        conversations.append({"partner": partner, "last_message": last_msg, "unread": unread})
        data.append({
            "partner_id": partner_id,
            "last_content": last_msg.content,
            "last_created_at": last_msg.created_at.strftime("%d/%m/%Y %H:%M"),
            "last_sender_id": last_msg.sender_id,
            "unread": unread,
        })

    conversations.sort(key=lambda c: c["last_message"].created_at, reverse=True)
    for conv, entry in zip(conversations, data):
        entry["html"] = render_template("_chat_inbox_row_fragment.html", conv=conv)

    return jsonify({"conversations": data, "total_unread": current_user.unread_messages_count})
