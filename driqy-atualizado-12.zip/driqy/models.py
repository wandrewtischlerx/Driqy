from datetime import datetime, timedelta

from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

from extensions import db


class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(30), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)

    # personalização de perfil
    display_name = db.Column(db.String(50), default="")
    bio = db.Column(db.String(280), default="")
    location = db.Column(db.String(80), default="")
    accent_color = db.Column(db.String(20), default="amber")
    avatar_filename = db.Column(db.String(255), nullable=True)
    cover_filename = db.Column(db.String(255), nullable=True)

    is_admin = db.Column(db.Boolean, default=False, nullable=False)
    is_moderator = db.Column(db.Boolean, default=False, nullable=False)
    is_banned = db.Column(db.Boolean, default=False, nullable=False)
    is_verified = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # contadores permanentes usados no ranking (não somem quando os posts expiram)
    total_likes_received = db.Column(db.Integer, default=0, nullable=False)
    total_comments_received = db.Column(db.Integer, default=0, nullable=False)

    posts = db.relationship(
        "Post", backref="author", lazy="dynamic", cascade="all, delete-orphan"
    )
    comments = db.relationship(
        "Comment", backref="author", lazy="dynamic", cascade="all, delete-orphan"
    )
    likes = db.relationship(
        "Like", backref="user", lazy="dynamic", cascade="all, delete-orphan"
    )

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    @property
    def display_label(self):
        return self.display_name.strip() if self.display_name and self.display_name.strip() else self.username

    @property
    def is_staff(self):
        """Admins e moderadores, juntos: quem tem poder de moderação."""
        return self.is_admin or self.is_moderator

    @property
    def badge_kind(self):
        """
        Define qual selo aparece ao lado do nome do usuário.
        Admins e moderadores recebem um selo especial (mais alto na hierarquia
        que o selo azul de verificação normal), mesmo que 'is_verified' seja falso.
        """
        if self.is_admin:
            return "admin"
        if self.is_moderator:
            return "mod"
        if self.is_verified:
            return "verified"
        return None

    # --- helpers de relacionamento (seguir / seguidores) ---
    def is_following(self, other_user):
        return Follow.query.filter_by(
            follower_id=self.id, followed_id=other_user.id
        ).first() is not None

    def follow(self, other_user):
        if other_user.id == self.id or self.is_following(other_user):
            return False
        db.session.add(Follow(follower_id=self.id, followed_id=other_user.id))
        return True

    def unfollow(self, other_user):
        link = Follow.query.filter_by(
            follower_id=self.id, followed_id=other_user.id
        ).first()
        if link:
            db.session.delete(link)
            return True
        return False

    def has_liked(self, post):
        return Like.query.filter_by(user_id=self.id, post_id=post.id).first() is not None

    @property
    def followers_count(self):
        return Follow.query.filter_by(followed_id=self.id).count()

    @property
    def following_count(self):
        return Follow.query.filter_by(follower_id=self.id).count()

    @property
    def active_posts_count(self):
        return self.posts.filter(Post.expires_at > datetime.utcnow()).count()

    @property
    def unread_notifications_count(self):
        return Notification.query.filter_by(recipient_id=self.id, is_read=False).count()

    @property
    def unread_messages_count(self):
        return Message.query.filter_by(recipient_id=self.id, is_read=False).count()

    @property
    def ranking_score(self):
        from flask import current_app
        w_likes = current_app.config.get("RANK_WEIGHT_LIKES", 2)
        w_comments = current_app.config.get("RANK_WEIGHT_COMMENTS", 1)
        w_followers = current_app.config.get("RANK_WEIGHT_FOLLOWERS", 3)
        return (
            self.total_likes_received * w_likes
            + self.total_comments_received * w_comments
            + self.followers_count * w_followers
        )

    def get_id(self):
        # sobrescreve para permitir invalidar sessão de usuários banidos
        return str(self.id)

    @property
    def is_active(self):
        return not self.is_banned

    def __repr__(self):
        return f"<User {self.username}>"


class Follow(db.Model):
    __tablename__ = "follows"

    id = db.Column(db.Integer, primary_key=True)
    follower_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    followed_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    follower = db.relationship("User", foreign_keys=[follower_id])
    followed = db.relationship("User", foreign_keys=[followed_id])

    __table_args__ = (
        db.UniqueConstraint("follower_id", "followed_id", name="uix_follow_pair"),
    )


class Post(db.Model):
    __tablename__ = "posts"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)

    post_type = db.Column(db.String(10), nullable=False)  # text | photo | video | gif
    text_content = db.Column(db.Text, nullable=True)
    media_filename = db.Column(db.String(255), nullable=True)

    duration_minutes = db.Column(db.Integer, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    expires_at = db.Column(db.DateTime, nullable=False, index=True)
    views_count = db.Column(db.Integer, default=0, nullable=False)

    comments = db.relationship(
        "Comment", backref="post", lazy="dynamic",
        cascade="all, delete-orphan", order_by="Comment.created_at.asc()",
    )
    post_likes = db.relationship(
        "Like", backref="post", lazy="dynamic", cascade="all, delete-orphan"
    )
    media_items = db.relationship(
        "PostMedia", backref="post", lazy="select",
        cascade="all, delete-orphan", order_by="PostMedia.position.asc()",
    )

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        if not self.created_at:
            self.created_at = datetime.utcnow()
        if not self.expires_at and self.duration_minutes:
            self.expires_at = self.created_at + timedelta(minutes=self.duration_minutes)

    @property
    def seconds_remaining(self):
        delta = (self.expires_at - datetime.utcnow()).total_seconds()
        return max(0, int(delta))

    @property
    def is_expired(self):
        return datetime.utcnow() >= self.expires_at

    @property
    def likes_count(self):
        return self.post_likes.count()

    @property
    def comments_count(self):
        return self.comments.count()

    @property
    def display_media(self):
        """
        Lista de mídias do post, em ordem, pronta para os templates.
        Usa as linhas em `post_media` quando existirem (posts com múltiplos
        arquivos); se não houver nenhuma, cai para `media_filename`, o campo
        legado usado por posts criados antes do suporte a múltiplas mídias.
        Cada item é um dict com "filename" e "media_type".
        """
        if self.media_items:
            return [{"filename": m.filename, "media_type": m.media_type} for m in self.media_items]
        if self.media_filename:
            media_type = self.post_type if self.post_type in ("photo", "video", "gif") else "photo"
            return [{"filename": self.media_filename, "media_type": media_type}]
        return []

    @property
    def media_count(self):
        return len(self.media_items) if self.media_items else (1 if self.media_filename else 0)

    def all_media_filenames(self):
        """Todos os nomes de arquivo associados ao post (novos e legados), sem duplicatas."""
        names = {m.filename for m in self.media_items}
        if self.media_filename:
            names.add(self.media_filename)
        return names

    def __repr__(self):
        return f"<Post {self.id} by user {self.user_id} ({self.post_type})>"


class PostMedia(db.Model):
    """
    Um arquivo de mídia (foto, vídeo ou GIF) dentro de um post.
    Um post pode ter várias linhas aqui (até o limite configurado em
    MAX_MEDIA_ITEMS), permitindo publicar várias fotos e vídeos juntos,
    exibidos em grade e abertos num carrossel ao clicar.
    """
    __tablename__ = "post_media"

    id = db.Column(db.Integer, primary_key=True)
    post_id = db.Column(db.Integer, db.ForeignKey("posts.id"), nullable=False, index=True)
    filename = db.Column(db.String(255), nullable=False)
    media_type = db.Column(db.String(10), nullable=False)  # photo | video | gif
    position = db.Column(db.Integer, default=0, nullable=False)

    def __repr__(self):
        return f"<PostMedia {self.id} post={self.post_id} ({self.media_type})>"


class Like(db.Model):
    __tablename__ = "likes"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    post_id = db.Column(db.Integer, db.ForeignKey("posts.id"), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (
        db.UniqueConstraint("user_id", "post_id", name="uix_like_pair"),
    )


class Comment(db.Model):
    __tablename__ = "comments"

    id = db.Column(db.Integer, primary_key=True)
    post_id = db.Column(db.Integer, db.ForeignKey("posts.id"), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    parent_id = db.Column(db.Integer, db.ForeignKey("comments.id"), nullable=True, index=True)
    content = db.Column(db.String(300), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    replies = db.relationship(
        "Comment",
        backref=db.backref("parent", remote_side=[id]),
        order_by="Comment.created_at.asc()",
        lazy="dynamic",
    )

    def __repr__(self):
        return f"<Comment {self.id} on post {self.post_id}>"


class Notification(db.Model):
    """
    Notificação enviada a um usuário quando alguém curte um post dele,
    comenta em um post dele, ou passa a segui-lo.
    `post` e `comment` são opcionais e podem ficar "órfãos" (apontando para
    um id que não existe mais) se o post expirar e for removido depois da
    notificação ser criada — os templates tratam isso mostrando só o texto.
    """
    __tablename__ = "notifications"

    KIND_LIKE = "like"
    KIND_COMMENT = "comment"
    KIND_FOLLOW = "follow"
    KIND_REPLY = "reply"

    id = db.Column(db.Integer, primary_key=True)
    recipient_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    actor_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    kind = db.Column(db.String(20), nullable=False)
    post_id = db.Column(db.Integer, db.ForeignKey("posts.id"), nullable=True)
    comment_id = db.Column(db.Integer, db.ForeignKey("comments.id"), nullable=True)
    is_read = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    recipient = db.relationship(
        "User", foreign_keys=[recipient_id],
        backref=db.backref("notifications", lazy="dynamic", cascade="all, delete-orphan",
                            order_by="Notification.created_at.desc()"),
    )
    actor = db.relationship("User", foreign_keys=[actor_id])
    post = db.relationship("Post")
    comment = db.relationship("Comment")

    @property
    def verb(self):
        return {
            self.KIND_LIKE: "curtiu seu post",
            self.KIND_COMMENT: "comentou no seu post",
            self.KIND_FOLLOW: "começou a seguir você",
            self.KIND_REPLY: "respondeu seu comentário",
        }.get(self.kind, "")

    def __repr__(self):
        return f"<Notification {self.kind} -> {self.recipient_id}>"


class Message(db.Model):
    """
    Mensagem direta trocada entre dois usuários (chat 1-para-1).
    Uma "conversa" não tem tabela própria: é simplesmente o conjunto de
    mensagens onde (sender, recipient) é um par de usuários, em qualquer
    ordem — ver as consultas em chat.py.
    """
    __tablename__ = "messages"

    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    recipient_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    content = db.Column(db.String(2000), nullable=False)
    is_read = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    sender = db.relationship("User", foreign_keys=[sender_id])
    recipient = db.relationship("User", foreign_keys=[recipient_id])

    def __repr__(self):
        return f"<Message {self.id} {self.sender_id} -> {self.recipient_id}>"


def create_notification(recipient, actor, kind, post=None, comment=None):
    """
    Cria uma notificação para `recipient` a partir da ação de `actor`.
    Não faz nada (e retorna None) se o próprio usuário for o alvo da ação
    (ex.: curtir/comentar no próprio post), já que ninguém precisa ser
    notificado sobre a própria atividade.
    """
    if recipient is None or actor is None or recipient.id == actor.id:
        return None
    notif = Notification(
        recipient_id=recipient.id,
        actor_id=actor.id,
        kind=kind,
        post_id=post.id if post is not None else None,
        comment_id=comment.id if comment is not None else None,
    )
    db.session.add(notif)
    return notif
