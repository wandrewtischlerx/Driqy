import re

from markupsafe import Markup, escape

MENTION_RE = re.compile(r"(?<!\w)@([a-zA-Z0-9_]{3,20})")


def linkify_mentions(text, valid_usernames=None):
    """
    Transforma @usuario em link para o perfil, quando o usuário existe.
    `valid_usernames` é opcional: um set de usernames válidos (lowercase) para
    evitar uma query ao banco por menção quando já se sabe quais existem.
    Sempre escapa o texto original antes de inserir os links (previne XSS).
    """
    if not text:
        return Markup("")

    safe_text = str(escape(text))

    def replace(match):
        username = match.group(1)
        exists = True
        if valid_usernames is not None:
            exists = username.lower() in valid_usernames
        else:
            from models import User
            exists = User.query.filter(
                User.username.ilike(username)
            ).first() is not None

        if not exists:
            return match.group(0)

        from flask import url_for
        url = url_for("main.profile", username=username)
        return f'<a href="{url}" class="mention-link">@{username}</a>'

    return Markup(MENTION_RE.sub(replace, safe_text))
