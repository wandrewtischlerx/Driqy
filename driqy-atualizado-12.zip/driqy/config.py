import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:
    SITE_NAME = "Driqy"

    SECRET_KEY = os.environ.get("SECRET_KEY", "troque-esta-chave-em-producao")
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL", f"sqlite:///{os.path.join(BASE_DIR, 'instance', 'driqy.db')}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    UPLOAD_FOLDER = os.path.join(BASE_DIR, "static", "uploads")
    MAX_CONTENT_LENGTH = 60 * 1024 * 1024  # 60 MB por upload

    ALLOWED_IMAGE_EXT = {"png", "jpg", "jpeg", "webp"}
    ALLOWED_GIF_EXT = {"gif"}
    ALLOWED_VIDEO_EXT = {"mp4", "webm", "mov"}

    # quantidade máxima de fotos/vídeos que podem ser publicados em um único post
    MAX_MEDIA_ITEMS = 10

    # duração dos posts, em minutos
    MIN_DURATION_MINUTES = 1
    MAX_DURATION_MINUTES = 60 * 24 * 365  # 1 ano

    # duraçoes pré-definidas mostradas no formulário (em minutos)
    DURATION_PRESETS = [
        (1, "1 minuto"),
        (5, "5 minutos"),
        (30, "30 minutos"),
        (60, "1 hora"),
        (360, "6 horas"),
        (1440, "1 dia"),
        (4320, "3 dias"),
        (10080, "1 semana"),
        (43200, "1 mês"),
        (129600, "3 meses"),
        (259200, "6 meses"),
        (525600, "1 ano"),
    ]

    POSTS_PER_PAGE = 15
    USERS_PER_PAGE = 20
    NOTIFICATIONS_PER_PAGE = 20
    # intervalo (segundos) em que o scheduler varre posts expirados
    CLEANUP_INTERVAL_SECONDS = 20

    # opções de cor de destaque para personalização de perfil
    # essa cor é a "marca" do usuário: aparece no nome, avatar padrão e
    # na borda de todos os posts dele
    ACCENT_COLORS = [
        ("amber", "#f2a93b"),
        ("rose", "#e85d75"),
        ("violet", "#9b7bd8"),
        ("teal", "#4fb6a8"),
        ("blue", "#5b9bd8"),
        ("lime", "#a3c95a"),
        ("coral", "#f2765c"),
        ("fuchsia", "#d858b8"),
        ("gold", "#d8b354"),
        ("sky", "#5ec8e0"),
        ("mint", "#5fd6a0"),
        ("slate", "#8f9bbf"),
    ]
    DEFAULT_ACCENT = "amber"

    # temas visuais disponíveis para o site (apenas claro e escuro)
    THEMES = [
        ("dark", "Escuro"),
        ("light", "Claro"),
    ]
    DEFAULT_THEME = "dark"

    # pesos usados para calcular a pontuação de ranking
    RANK_WEIGHT_LIKES = 2
    RANK_WEIGHT_COMMENTS = 1
    RANK_WEIGHT_FOLLOWERS = 3

    MAX_COMMENT_LENGTH = 300
