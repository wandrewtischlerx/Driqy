# Driqy — rede social com posts temporários

Base funcional de uma rede social em Python (Flask) onde **todo post tem prazo de validade**,
escolhido pelo autor entre 1 minuto e 1 ano. Quando o tempo acaba, o post some sozinho
(banco de dados e arquivo de mídia são apagados automaticamente). Enquanto está ativo,
o autor **não pode apagar** o post manualmente.

## Funcionalidades

- **Cadastro e login** de usuários (senha com hash, sessão via Flask-Login).
- **Perfis com personalização**: nome de exibição, bio, localização, foto de avatar,
  **@ editável** (troca de nome de usuário com validação de unicidade) e uma **cor de
  marca** (escolhida entre 12 opções) que aparece no nome, no avatar padrão e na borda
  esquerda de todos os posts do usuário — tudo editável em `/perfil/editar`.
- **Contas verificadas**: administradores podem conceder/remover um selo de verificação
  (✓), exibido ao lado do nome em posts, comentários, perfil, ranking e painel admin.
- **Temas visuais**: alternância entre 4 temas (Escuro, Claro, Crepúsculo, Oceano),
  salva no navegador do usuário (localStorage), sem necessidade de login.
- **Interface responsiva**: menu hambúrguer em telas pequenas, tabelas com rolagem
  horizontal, alvos de toque ampliados e layout adaptado para celulares e tablets.
- **Sistema de @ nicknames**: qualquer `@usuario` escrito em posts, comentários ou bio
  vira automaticamente um link clicável para o perfil da pessoa (só quando o usuário existe).
- **Seguir / deixar de seguir** outros perfis.
- **Curtidas**: qualquer usuário logado pode curtir/descurtir um post ativo.
- **Comentários**: comentários curtos em posts ativos, com suporte a @menções;
  eles desaparecem junto com o post quando ele expira.
- **Ranking**: página `/ranking` que classifica os usuários por uma pontuação
  combinando curtidas recebidas, comentários recebidos e número de seguidores.
  Essa pontuação é **permanente** — não zera quando os posts expiram, funcionando
  como um histórico de reputação na rede.
- **Posts com tipo**: texto, foto, vídeo ou GIF, cada um com sua própria duração (1 min a 1 ano).
- **Feed global** com os posts mais recentes que ainda não expiraram.
- **Contagem regressiva visual** (anel + texto) em cada post, atualizada em tempo real no navegador.
- **Expiração automática de verdade**: um job em background (APScheduler) roda periodicamente
  e apaga do banco (e do disco) qualquer post cujo tempo tenha acabado — não depende do
  usuário estar com a página aberta. Comentários e curtidas do post são removidos junto.
- **Painel de administração** (`/admin`):
  - Visão geral com estatísticas ampliadas: usuários totais, novos em 7 dias, contas
    verificadas, admins, banidos, posts ativos/expirados, posts publicados em 7 dias,
    curtidas e comentários totais, posts por tipo (texto/foto/vídeo/GIF) e top ranking.
  - Gestão de contas: banir/desbanir, **verificar/remover selo**, promover/remover
    admin, excluir conta.
  - Moderação de posts e de comentários individuais.
  - Acesso restrito a usuários com `is_admin = True` (o primeiro usuário cadastrado
    no sistema vira admin automaticamente).

## Como rodar

```bash
# 1. crie um ambiente virtual (recomendado)
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 2. instale as dependências
pip install -r requirements.txt

# 3. rode o servidor
python app.py
```

Acesse http://localhost:5000 no navegador. O banco de dados SQLite é criado
automaticamente em `instance/driqy.db` na primeira execução.

> O **primeiro usuário que você cadastrar** vira administrador automaticamente e
> passa a ver o link "Admin" no menu. Os próximos cadastros são usuários comuns.

> **Já tinha um banco de dados de uma versão anterior deste projeto?** Esta versão
> adicionou colunas novas (personalização de perfil, contadores de ranking) e tabelas
> novas (curtidas, comentários). O SQLite não cria colunas em tabelas já existentes
> sozinho, então apague `instance/driqy.db` antes de rodar `python app.py` de novo
> — um banco novo e vazio será criado automaticamente com a estrutura atualizada.

## Estrutura do projeto

```
driqy/
├── app.py              # application factory, registra blueprints, filtros e inicia o scheduler
├── config.py            # configurações (durações, extensões aceitas, cores, pesos do ranking)
├── extensions.py        # instâncias do SQLAlchemy e do Flask-Login
├── models.py             # User, Post, Follow, Like, Comment
├── mentions.py            # conversão de @usuario em links de perfil
├── auth.py               # cadastro, login, logout
├── main.py               # feed, posts, perfil, seguir, likes, comentários, ranking
├── admin.py               # painel administrativo
├── scheduler.py            # job em background que apaga posts expirados
├── templates/               # HTML (Jinja2)
│   └── admin/
├── static/
│   ├── css/style.css
│   ├── js/countdown.js       # contagem regressiva + toggle de comentários
│   ├── js/ui.js               # troca de tema + menu mobile
│   └── uploads/                # arquivos de mídia e avatares enviados pelos usuários
└── requirements.txt
```

## Detalhes de implementação importantes

- **Duração do post**: campo `duration_minutes` em `Post`, validado no backend entre
  `MIN_DURATION_MINUTES` (1) e `MAX_DURATION_MINUTES` (525600 = 1 ano), definidos em `config.py`.
  `expires_at` é calculado automaticamente na criação do post.
- **Por que o usuário não consegue apagar**: propositalmente **não existe rota** de exclusão
  de post para usuários comuns — apenas o job automático (`scheduler.py`) e o admin
  (`admin.delete_post`, usado para moderação) podem remover um post.
- **Limpeza automática**: `scheduler.py` usa `APScheduler` com um job de intervalo
  (`CLEANUP_INTERVAL_SECONDS`, padrão 20s) que varre `Post.expires_at <= agora`,
  apaga o arquivo de mídia do disco e remove a linha do banco.
- **Contagem regressiva**: cada card de post carrega `data-expires` e `data-duration`
  em atributos HTML; `countdown.js` atualiza um anel SVG e um rótulo de tempo a cada
  segundo, e remove o card da tela com uma animação quando chega a zero — mesmo que
  o scheduler ainda não tenha rodado nesse exato segundo.

## Próximos passos sugeridos (não incluídos nesta base)

- Upload de avatar de perfil.
- Curtidas/comentários (que também poderiam expirar).
- Notificações em tempo real (WebSocket) em vez de polling.
- Paginação "infinita" no feed com JavaScript.
- Deploy com um servidor WSGI de produção (gunicorn/uwsgi) atrás de Nginx.
