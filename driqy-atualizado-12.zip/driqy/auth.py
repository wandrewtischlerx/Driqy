import re

from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user

from extensions import db
from models import User

auth_bp = Blueprint("auth", __name__)

USERNAME_RE = re.compile(r"^[a-zA-Z0-9_]{3,20}$")


@auth_bp.route("/registrar", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("main.feed"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        password2 = request.form.get("password2", "")

        errors = []
        if not USERNAME_RE.match(username):
            errors.append(
                "Nome de usuário deve ter 3-20 caracteres: letras, números ou _."
            )
        if not email or "@" not in email:
            errors.append("E-mail inválido.")
        if len(password) < 6:
            errors.append("A senha deve ter pelo menos 6 caracteres.")
        if password != password2:
            errors.append("As senhas não coincidem.")
        if User.query.filter_by(username=username).first():
            errors.append("Esse nome de usuário já está em uso.")
        if User.query.filter_by(email=email).first():
            errors.append("Esse e-mail já está cadastrado.")

        if errors:
            for e in errors:
                flash(e, "danger")
            return render_template("register.html", username=username, email=email)

        user = User(username=username, email=email)
        user.set_password(password)

        # o primeiro usuário cadastrado no sistema vira admin automaticamente
        if User.query.count() == 0:
            user.is_admin = True

        db.session.add(user)
        db.session.commit()

        flash("Conta criada com sucesso! Faça login.", "success")
        return redirect(url_for("auth.login"))

    return render_template("register.html")


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("main.feed"))

    if request.method == "POST":
        identifier = request.form.get("identifier", "").strip().lower()
        password = request.form.get("password", "")

        user = User.query.filter(
            (User.username == identifier) | (User.email == identifier)
        ).first()

        if user is None or not user.check_password(password):
            flash("Usuário/e-mail ou senha incorretos.", "danger")
            return render_template("login.html")

        if user.is_banned:
            flash("Esta conta foi banida. Contate um administrador.", "danger")
            return render_template("login.html")

        login_user(user)
        flash(f"Bem-vindo(a) de volta, {user.username}!", "success")
        next_page = request.args.get("next")
        return redirect(next_page or url_for("main.feed"))

    return render_template("login.html")


@auth_bp.route("/logout")
@login_required
def logout():
    logout_user()
    flash("Você saiu da sua conta.", "info")
    return redirect(url_for("auth.login"))
