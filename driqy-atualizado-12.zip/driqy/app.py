import os
from datetime import datetime

from flask import Flask
from werkzeug.middleware.proxy_fix import ProxyFix

from config import Config
from extensions import db, login_manager


def _ensure_schema_upgrades(db):
    """
    Adiciona colunas novas em bancos já existentes (criados antes desta versão),
    sem precisar de uma ferramenta de migração completa. Seguro para rodar toda
    vez que o app sobe: só faz algo se a coluna ainda não existir.
    """
    from sqlalchemy import inspect, text

    inspector = inspect(db.engine)
    if "users" not in inspector.get_table_names():
        return
    existing_columns = {col["name"] for col in inspector.get_columns("users")}
    if "cover_filename" not in existing_columns:
        with db.engine.begin() as conn:
            conn.execute(text("ALTER TABLE users ADD COLUMN cover_filename VARCHAR(255)"))

    if "posts" in inspector.get_table_names():
        post_columns = {col["name"] for col in inspector.get_columns("posts")}
        if "views_count" not in post_columns:
            with db.engine.begin() as conn:
                conn.execute(text("ALTER TABLE posts ADD COLUMN views_count INTEGER NOT NULL DEFAULT 0"))


def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_prefix=1)

    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
    os.makedirs(os.path.join(os.path.dirname(__file__), "instance"), exist_ok=True)

    db.init_app(app)
    login_manager.init_app(app)

    from models import User

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    from auth import auth_bp
    from main import main_bp
    from admin import admin_bp
    from chat import chat_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(chat_bp)

    @app.context_processor
    def inject_now():
        return {
            "now": datetime.utcnow(),
            "site_name": app.config["SITE_NAME"],
            "themes": app.config["THEMES"],
            "default_theme": app.config["DEFAULT_THEME"],
        }

    @app.template_filter("mentions")
    def mentions_filter(text):
        from mentions import linkify_mentions
        return linkify_mentions(text)

    @app.template_filter("accent_hex")
    def accent_hex_filter(color_key):
        mapping = dict(app.config["ACCENT_COLORS"])
        return mapping.get(color_key, mapping.get(app.config["DEFAULT_ACCENT"]))

    @app.errorhandler(403)
    def forbidden(e):
        return ("Acesso negado: você não tem permissão para ver esta página.", 403)

    @app.errorhandler(404)
    def not_found(e):
        return ("Página não encontrada.", 404)

    @app.route("/favicon.ico")
    def favicon_root():
        # Vários navegadores pedem /favicon.ico direto na raiz, ignorando as
        # tags <link> do <head> — isso garante que ele sempre seja encontrado.
        from flask import send_from_directory
        return send_from_directory(
            os.path.join(app.static_folder, "icons"), "favicon.ico"
        )

    with app.app_context():
        db.create_all()
        _ensure_schema_upgrades(db)

    # inicia o agendador que apaga posts expirados automaticamente
    if not app.config.get("TESTING"):
        from models import Post
        from scheduler import start_scheduler
        start_scheduler(app, db, Post)

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(debug=True, host="0.0.0.0", port=5000)
