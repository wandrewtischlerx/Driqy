(function () {
  const scriptTag = document.currentScript;

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, (c) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
    }[c]));
  }

  function badgeSvg(kind) {
    if (!kind) return "";
    return ' <span class="mini-badge mini-badge-' + kind + '" title="conta ' + kind + '">✓</span>';
  }

  function renderResults(container, users) {
    if (!users.length) {
      container.innerHTML = '<p class="hint search-dropdown-empty">Nenhuma pessoa encontrada.</p>';
      return;
    }
    container.innerHTML = users.map((u) => {
      const avatar = u.avatar
        ? '<img class="avatar-dot avatar-img" src="' + u.avatar + '" alt="">'
        : '<span class="avatar-dot" style="background: linear-gradient(135deg, ' + u.accent + ', var(--rose));">' + escapeHtml(u.initial) + '</span>';
      return (
        '<a class="search-result-item" href="' + u.profile_url + '">' +
        avatar +
        '<span><span class="user-list-name">' + escapeHtml(u.display_name) + badgeSvg(u.badge_kind) + '</span>' +
        '<div class="post-meta">@' + escapeHtml(u.username) + '</div></span>' +
        '</a>'
      );
    }).join("");
  }

  document.addEventListener("DOMContentLoaded", () => {
    const url = scriptTag && scriptTag.dataset.searchUrl;
    const wrap = document.getElementById("topbar-search");
    const input = document.getElementById("topbar-search-input");
    const dropdown = document.getElementById("search-dropdown");
    if (!url || !wrap || !input || !dropdown) return;

    let debounceTimer = null;
    let lastQuery = "";

    input.addEventListener("input", () => {
      const q = input.value.trim();
      clearTimeout(debounceTimer);
      if (!q) {
        dropdown.hidden = true;
        dropdown.innerHTML = "";
        return;
      }
      debounceTimer = setTimeout(() => {
        lastQuery = q;
        fetch(url + "?q=" + encodeURIComponent(q), { headers: { "X-Requested-With": "fetch" } })
          .then((res) => (res.ok ? res.json() : null))
          .then((data) => {
            if (!data || lastQuery !== q) return;
            renderResults(dropdown, data.users || []);
            dropdown.hidden = false;
          })
          .catch(() => {});
      }, 220);
    });

    input.addEventListener("focus", () => {
      if (input.value.trim() && dropdown.innerHTML) dropdown.hidden = false;
    });

    document.addEventListener("click", (event) => {
      if (!wrap.contains(event.target)) {
        dropdown.hidden = true;
      }
    });

    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape") dropdown.hidden = true;
    });
  });
})();
