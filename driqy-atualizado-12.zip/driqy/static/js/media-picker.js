/*
 * Seletor de múltiplos arquivos de mídia (fotos, vídeos ou GIFs), reutilizado
 * tanto na caixa de publicação rápida do feed quanto na página completa de
 * publicar. Mantém uma lista de arquivos escolhidos (até `maxItems`), gera
 * miniaturas com botão para remover cada uma individualmente, e mantém o
 * <input type="file"> real sincronizado (via DataTransfer) para o envio do
 * formulário.
 */
(function () {
  function attachMediaPicker({ fileInput, previewContainer, counterEl, maxItems = 10, onChange, onLimit }) {
    let files = [];
    let objectUrls = [];

    function revokeAll() {
      objectUrls.forEach((url) => URL.revokeObjectURL(url));
      objectUrls = [];
    }

    function syncInput() {
      const dt = new DataTransfer();
      files.forEach((f) => dt.items.add(f));
      fileInput.files = dt.files;
    }

    function isVideo(file) {
      return file.type.startsWith("video/") || /\.(mp4|webm|mov)$/i.test(file.name);
    }

    function render() {
      revokeAll();
      previewContainer.innerHTML = "";
      previewContainer.hidden = files.length === 0;

      files.forEach((file, idx) => {
        const url = URL.createObjectURL(file);
        objectUrls.push(url);

        const item = document.createElement("div");
        item.className = "media-picker-item";

        if (isVideo(file)) {
          const video = document.createElement("video");
          video.src = url;
          video.muted = true;
          video.playsInline = true;
          item.appendChild(video);

          const badge = document.createElement("span");
          badge.className = "media-picker-video-badge";
          badge.innerHTML = '<svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path fill="currentColor" d="M8 5v14l11-7z"/></svg>';
          item.appendChild(badge);
        } else {
          const img = document.createElement("img");
          img.src = url;
          img.alt = "Prévia da mídia " + (idx + 1);
          item.appendChild(img);
        }

        const removeBtn = document.createElement("button");
        removeBtn.type = "button";
        removeBtn.className = "media-picker-remove";
        removeBtn.setAttribute("aria-label", "Remover este item");
        removeBtn.textContent = "✕";
        removeBtn.addEventListener("click", (e) => {
          e.preventDefault();
          e.stopPropagation();
          files.splice(idx, 1);
          syncInput();
          render();
          if (onChange) onChange(files.length);
        });
        item.appendChild(removeBtn);

        previewContainer.appendChild(item);
      });

      if (counterEl) {
        counterEl.hidden = files.length === 0;
        counterEl.textContent = files.length + "/" + maxItems;
      }
    }

    fileInput.addEventListener("change", () => {
      const picked = Array.from(fileInput.files || []);
      const room = maxItems - files.length;
      if (picked.length > room && onLimit) onLimit(maxItems);
      files = files.concat(picked.slice(0, Math.max(0, room)));
      syncInput();
      render();
      if (onChange) onChange(files.length);
    });

    return {
      clear() {
        files = [];
        syncInput();
        render();
        if (onChange) onChange(files.length);
      },
      count() {
        return files.length;
      },
    };
  }

  window.driqyAttachMediaPicker = attachMediaPicker;
})();
