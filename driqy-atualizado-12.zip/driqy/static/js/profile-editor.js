/*
 * Editor de foto de perfil e capa.
 * Deixa a pessoa escolher uma imagem, arrastar para posicionar e usar um
 * controle de zoom antes de enviar — tudo no navegador, sem depender de
 * bibliotecas externas. O resultado final já sai recortado no tamanho certo
 * (quadrado para avatar, panorâmico para capa) para o servidor só salvar.
 */
(function () {
  document.addEventListener("DOMContentLoaded", () => {
    const overlay = document.getElementById("cropper-overlay");
    const modal = document.getElementById("cropper-modal");
    const canvas = document.getElementById("cropper-canvas");
    const canvasWrap = document.getElementById("cropper-canvas-wrap");
    const zoomInput = document.getElementById("cropper-zoom");
    const closeBtn = document.getElementById("cropper-close");
    const cancelBtn = document.getElementById("cropper-cancel");
    const applyBtn = document.getElementById("cropper-apply");
    const previewBox = document.getElementById("cropper-preview-box");

    if (!overlay || !modal || !canvas) return; // página sem editor de imagem
    const ctx = canvas.getContext("2d");

    // Guarda a última URL de objeto criada por alvo (avatar/capa), pra poder
    // liberar a memória da anterior quando uma nova é aplicada.
    const lastObjectUrls = {};

    const targets = {
      avatar: {
        fileInput: document.getElementById("avatar_file"),
        changeBtn: document.getElementById("avatar-change-btn"),
        removeBtn: document.getElementById("avatar-remove-btn"),
        removeFlag: document.getElementById("remove_avatar"),
        frame: document.getElementById("avatar-frame"),
        quickForm: document.getElementById("avatar-quick-form"),
        shape: "circle",
        outputW: 480,
        outputH: 480,
        placeholder: document.getElementById("avatar-frame")
          ? document.getElementById("avatar-frame").getAttribute("style")
          : "",
      },
      cover: {
        fileInput: document.getElementById("cover_file"),
        changeBtn: document.getElementById("cover-change-btn"),
        removeBtn: document.getElementById("cover-remove-btn"),
        removeFlag: document.getElementById("remove_cover"),
        frame: document.getElementById("cover-frame"),
        shape: "rect",
        outputW: 1200,
        outputH: 400,
      },
    };

    let current = null; // 'avatar' | 'cover'
    let img = null;
    let baseScale = 1;
    let zoom = 1;
    let offsetX = 0;
    let offsetY = 0;
    let dragging = false;
    let lastX = 0;
    let lastY = 0;

    function totalScale() {
      return baseScale * zoom;
    }

    function clampOffsets() {
      const scale = totalScale();
      const drawW = img.width * scale;
      const drawH = img.height * scale;
      const minX = Math.min(0, canvas.width - drawW);
      const minY = Math.min(0, canvas.height - drawH);
      offsetX = Math.max(minX, Math.min(0, offsetX));
      offsetY = Math.max(minY, Math.min(0, offsetY));
    }

    let previewRaf = null;
    function schedulePreviewUpdate() {
      if (previewRaf) return; // já tem uma atualização de preview agendada
      previewRaf = requestAnimationFrame(() => {
        previewRaf = null;
        if (!previewBox || !current) return;
        const cfg = targets[current];
        previewBox.classList.toggle("cropper-preview-rect", cfg.shape === "rect");
        try {
          previewBox.style.backgroundImage = `url('${canvas.toDataURL("image/jpeg", 0.85)}')`;
        } catch (e) {
          // canvas ainda vazio ou navegador bloqueou toDataURL — ignora silenciosamente
        }
      });
    }

    function draw() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      // Base branca: sem isso, qualquer pixel transparente da imagem original
      // (comum em avatares/logos em PNG) vira preto sólido quando exportamos
      // pra JPEG, que não tem canal alfa. É essa base que evita o bug do
      // avatar/capa aparecendo com metade preta, tanto na prévia quanto na
      // imagem final salva.
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.save();
      ctx.translate(offsetX, offsetY);
      ctx.scale(totalScale(), totalScale());
      ctx.drawImage(img, 0, 0);
      ctx.restore();
      schedulePreviewUpdate();
    }

    function openModalFor(key, dataUrl) {
      const cfg = targets[key];
      current = key;
      canvas.width = cfg.outputW;
      canvas.height = cfg.outputH;
      canvasWrap.classList.toggle("cropper-canvas-wrap-circle", cfg.shape === "circle");
      canvasWrap.classList.toggle("cropper-canvas-wrap-rect", cfg.shape === "rect");
      document.getElementById("cropper-title").textContent =
        key === "avatar" ? "Ajustar foto de perfil" : "Ajustar foto de capa";

      if (previewBox) {
        previewBox.style.backgroundImage = "none";
        previewBox.classList.toggle("cropper-preview-rect", cfg.shape === "rect");
      }
      if (applyBtn) applyBtn.disabled = true;

      img = new Image();
      img.onload = () => {
        baseScale = Math.max(cfg.outputW / img.width, cfg.outputH / img.height);
        zoom = 1;
        zoomInput.value = "1";
        offsetX = (cfg.outputW - img.width * baseScale) / 2;
        offsetY = (cfg.outputH - img.height * baseScale) / 2;
        clampOffsets();
        draw();
        if (applyBtn) applyBtn.disabled = false;
      };
      img.onerror = () => {
        if (document.getElementById("cropper-title")) {
          document.getElementById("cropper-title").textContent = "Não foi possível abrir essa imagem";
        }
      };
      img.src = dataUrl;

      overlay.hidden = false;
      modal.hidden = false;
      document.body.style.overflow = "hidden";
    }

    function closeModal() {
      overlay.hidden = true;
      modal.hidden = true;
      document.body.style.overflow = "";
      current = null;
      img = null;
    }

    Object.keys(targets).forEach((key) => {
      const cfg = targets[key];
      if (!cfg.fileInput || !cfg.changeBtn) return;

      cfg.changeBtn.addEventListener("click", () => cfg.fileInput.click());

      cfg.fileInput.addEventListener("change", () => {
        const file = cfg.fileInput.files && cfg.fileInput.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (e) => openModalFor(key, e.target.result);
        reader.readAsDataURL(file);
      });

      if (cfg.removeBtn) {
        cfg.removeBtn.addEventListener("click", () => {
          cfg.removeFlag.value = "1";
          cfg.fileInput.value = "";
          cfg.frame.classList.remove("has-image");
          cfg.frame.style.backgroundImage = "none";
          cfg.removeBtn.hidden = true;
        });
      }
    });

    // ---------- Arrastar para posicionar ----------
    function pointerToCanvasDelta(dx, dy) {
      const rect = canvas.getBoundingClientRect();
      const scaleX = canvas.width / rect.width;
      const scaleY = canvas.height / rect.height;
      return [dx * scaleX, dy * scaleY];
    }

    canvas.addEventListener("pointerdown", (e) => {
      dragging = true;
      lastX = e.clientX;
      lastY = e.clientY;
      canvas.setPointerCapture(e.pointerId);
    });
    canvas.addEventListener("pointermove", (e) => {
      if (!dragging || !img) return;
      const [dx, dy] = pointerToCanvasDelta(e.clientX - lastX, e.clientY - lastY);
      offsetX += dx;
      offsetY += dy;
      lastX = e.clientX;
      lastY = e.clientY;
      clampOffsets();
      draw();
    });
    ["pointerup", "pointercancel", "pointerleave"].forEach((evt) => {
      canvas.addEventListener(evt, () => {
        dragging = false;
      });
    });

    zoomInput.addEventListener("input", () => {
      if (!img) return;
      zoom = parseFloat(zoomInput.value);
      clampOffsets();
      draw();
    });

    function closeAndReset(key) {
      const cfg = targets[key];
      if (cfg && cfg.fileInput) cfg.fileInput.value = "";
      closeModal();
    }

    closeBtn.addEventListener("click", () => closeAndReset(current));
    cancelBtn.addEventListener("click", () => closeAndReset(current));
    overlay.addEventListener("click", () => closeAndReset(current));

    applyBtn.addEventListener("click", () => {
      if (!current || !img) return;
      const key = current;
      const cfg = targets[key];

      canvas.toBlob(
        (blob) => {
          if (!blob) return;
          const fileName = key === "avatar" ? "avatar.jpg" : "capa.jpg";
          const croppedFile = new File([blob], fileName, { type: "image/jpeg" });
          const dt = new DataTransfer();
          dt.items.add(croppedFile);
          cfg.fileInput.files = dt.files;

          if (lastObjectUrls[key]) {
            URL.revokeObjectURL(lastObjectUrls[key]);
          }
          const objectUrl = URL.createObjectURL(blob);
          lastObjectUrls[key] = objectUrl;

          // Só troca a pré-visualização do quadro depois que a nova imagem
          // realmente carregou, pra nunca mostrar um estado em branco/antigo.
          const check = new Image();
          check.onload = () => {
            // Limpa qualquer "background" (shorthand) herdado do estado sem
            // imagem — ele reseta background-size/position pra inline, o que
            // fazia a prévia aparecer fora de enquadro até salvar e recarregar.
            cfg.frame.style.background = "";
            cfg.frame.style.backgroundImage = `url('${objectUrl}')`;
            cfg.frame.style.backgroundSize = "cover";
            cfg.frame.style.backgroundPosition = "center";
            cfg.frame.classList.add("has-image");
          };
          check.src = objectUrl;

          if (cfg.removeFlag) cfg.removeFlag.value = "0";
          if (cfg.removeBtn) cfg.removeBtn.hidden = false;

          closeModal();

          if (cfg.quickForm) {
            // Widget de troca rápida (ex: no próprio perfil): salva na hora,
            // sem precisar passar pela página "Editar perfil".
            if (typeof cfg.quickForm.requestSubmit === "function") {
              cfg.quickForm.requestSubmit();
            } else {
              cfg.quickForm.submit();
            }
          }
        },
        "image/jpeg",
        0.92
      );
    });
  });
})();
