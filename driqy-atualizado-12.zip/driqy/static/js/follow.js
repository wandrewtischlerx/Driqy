(function () {
  function setButtonState(btn, following) {
    btn.dataset.following = following ? "true" : "false";
    btn.classList.toggle("is-following", following);
    btn.textContent = following ? "Seguindo" : "Seguir";
  }

  document.addEventListener("click", (event) => {
    const btn = event.target.closest(".btn-follow");
    if (!btn) return;

    event.preventDefault();
    if (btn.disabled) return;

    const username = btn.dataset.followUsername;
    if (!username) return;

    const following = btn.dataset.following === "true";
    const action = following ? "deixar-de-seguir" : "seguir";
    const url = `/u/${encodeURIComponent(username)}/${action}`;

    btn.disabled = true;

    fetch(url, {
      method: "POST",
      headers: { "X-Requested-With": "fetch" },
    })
      .then((res) => (res.ok ? res.json() : Promise.reject(res)))
      .then((data) => {
        setButtonState(btn, data.following);
      })
      .catch(() => {
        // se algo der errado (ex.: sessão expirou), volta ao normal e
        // deixa o clique seguinte tentar de novo
      })
      .finally(() => {
        btn.disabled = false;
      });
  });
})();
