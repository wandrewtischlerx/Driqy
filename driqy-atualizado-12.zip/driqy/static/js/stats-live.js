(function () {
  const STATS_POLL_MS = 5000;
  const STATS_URL = "/api/feed/stats";

  function formatCompact(n) {
    if (n < 1000) return String(n);
    if (n < 1000000) {
      const v = n / 1000;
      return (v >= 10 ? v.toFixed(0) : v.toFixed(1).replace(/\.0$/, "")) + "K";
    }
    const v = n / 1000000;
    return (v >= 10 ? v.toFixed(0) : v.toFixed(1).replace(/\.0$/, "")) + "M";
  }

  function updateCardStats(card, stats) {
    if (!stats) return;

    const commentSpan = card.querySelector(".comment-toggle span:last-child");
    if (commentSpan) commentSpan.textContent = formatCompact(stats.comments_count);

    const likeSpan = card.querySelector(".like-btn span:last-child");
    if (likeSpan) likeSpan.textContent = formatCompact(stats.likes_count);

    const viewsSpan = card.querySelector(".views-count");
    if (viewsSpan) viewsSpan.textContent = formatCompact(stats.views_count);

    const likeBtn = card.querySelector(".like-btn:not(.disabled)");
    if (likeBtn && document.activeElement !== likeBtn) {
      likeBtn.classList.toggle("liked", !!stats.liked);
      const heart = likeBtn.querySelector(".heart");
      if (heart) heart.textContent = stats.liked ? "♥" : "♡";
    }
  }

  function visibleCards() {
    return Array.from(document.querySelectorAll(".post-card[id^='post-']"));
  }

  function pollStats() {
    const cards = visibleCards();
    if (!cards.length) return;

    const ids = cards.map((c) => c.id.replace("post-", "")).slice(0, 60);
    fetch(STATS_URL + "?ids=" + ids.join(","), { headers: { "X-Requested-With": "fetch" } })
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (!data || !data.posts) return;
        cards.forEach((card) => {
          const id = card.id.replace("post-", "");
          updateCardStats(card, data.posts[id]);
        });
      })
      .catch(() => {});
  }

  // Registra 1 visualização por post por sessão, quando o card entra na tela.
  const viewedThisPage = new Set();

  function setupViewTracking() {
    if (!("IntersectionObserver" in window)) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          const card = entry.target;
          const id = card.id.replace("post-", "");
          if (viewedThisPage.has(id)) return;
          viewedThisPage.add(id);
          observer.unobserve(card);

          fetch(`/post/${id}/visualizar`, { method: "POST", headers: { "X-Requested-With": "fetch" } })
            .then((res) => (res.ok ? res.json() : null))
            .then((data) => {
              if (!data) return;
              const viewsSpan = card.querySelector(".views-count");
              if (viewsSpan) viewsSpan.textContent = formatCompact(data.views_count);
            })
            .catch(() => {});
        });
      },
      { threshold: 0.5 }
    );

    function observeAll() {
      visibleCards().forEach((card) => {
        const id = card.id.replace("post-", "");
        if (!viewedThisPage.has(id)) observer.observe(card);
      });
    }

    observeAll();
    // reobserva cards novos inseridos pelo feed em tempo real
    const feedList = document.getElementById("feed-list");
    if (feedList && "MutationObserver" in window) {
      new MutationObserver(observeAll).observe(feedList, { childList: true });
    }
  }

  document.addEventListener("DOMContentLoaded", () => {
    setupViewTracking();
    setInterval(pollStats, STATS_POLL_MS);
  });

  window.driqyStats = { formatCompact };
})();
