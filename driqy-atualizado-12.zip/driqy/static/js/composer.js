/*
 * Caixa de publicação rápida no topo do feed ("O que está acontecendo?").
 * Cuida de: auto-crescer o textarea, anexar mídia com prévia (detectando o
 * tipo do post pela extensão do arquivo), escolher GIF, escolher a duração
 * do post (com um painel fluido de abrir/fechar) e habilitar o botão de
 * postar só quando há conteúdo válido. Anexar uma mídia apenas mostra a
 * prévia — o post só é publicado quando a pessoa clica em "Postar".
 */
(function () {
  document.addEventListener("DOMContentLoaded", () => {
    const card = document.getElementById("composer");
    if (!card) return; // página sem composer (ex: usuário não logado)

    const form = document.getElementById("composer-form");
    const textArea = document.getElementById("composer-text");
    const postTypeInput = document.getElementById("composer-post-type");
    const durationInput = document.getElementById("composer-duration-input");
    const durationLabel = document.getElementById("composer-duration-label");
    const durationBtn = document.getElementById("composer-duration-btn");
    const durationPanel = document.getElementById("composer-duration-panel");
    const postBtn = document.getElementById("composer-post-btn");
    const charCount = document.getElementById("composer-char-count");

    const mediaBtn = document.getElementById("composer-media-btn");
    const mediaFileInput = document.getElementById("composer-media-file");

    const mediaPreview = document.getElementById("composer-media-preview");
    const mediaCounter = document.getElementById("composer-media-counter");

    const MAX_MEDIA_ITEMS = 10;
    let hasMedia = false;

    // ---------- Textarea que cresce sozinho ----------
    function autoGrow() {
      textArea.style.height = "auto";
      textArea.style.height = textArea.scrollHeight + "px";
    }

    function updatePostState() {
      const hasText = textArea.value.trim().length > 0;
      postBtn.disabled = !(hasText || hasMedia);

      const len = textArea.value.length;
      if (len > 800) {
        charCount.hidden = false;
        charCount.textContent = (1000 - len).toString();
        charCount.classList.toggle("warn", len >= 1000);
      } else {
        charCount.hidden = true;
      }
    }

    textArea.addEventListener("input", () => {
      autoGrow();
      updatePostState();
    });

    // ---------- Painel de duração (fluido: abre/fecha com transição) ----------
    function closeDurationPanel() {
      if (!durationPanel) return;
      durationPanel.classList.remove("open");
      durationPanel.setAttribute("aria-hidden", "true");
      if (durationBtn) durationBtn.setAttribute("aria-expanded", "false");
    }

    function toggleDurationPanel() {
      if (!durationPanel) return;
      const willOpen = !durationPanel.classList.contains("open");
      durationPanel.classList.toggle("open", willOpen);
      durationPanel.setAttribute("aria-hidden", willOpen ? "false" : "true");
      if (durationBtn) durationBtn.setAttribute("aria-expanded", willOpen ? "true" : "false");
    }

    document.addEventListener("click", (e) => {
      if (!card.contains(e.target)) closeDurationPanel();
    });

    // ---------- Anexar mídia (fotos, vídeos ou GIFs — até 10 por post) ----------
    // Só monta a prévia; a publicação só acontece quando a pessoa clicar em
    // "Postar" (antes disso, dá pra revisar/remover qualquer item).
    window.driqyAttachMediaPicker({
      fileInput: mediaFileInput,
      previewContainer: mediaPreview,
      counterEl: mediaCounter,
      maxItems: MAX_MEDIA_ITEMS,
      onChange: (count) => {
        hasMedia = count > 0;
        postTypeInput.value = hasMedia ? "media" : "text";
        updatePostState();
      },
      onLimit: (max) => {
        alert(`Você pode anexar no máximo ${max} fotos/vídeos por post.`);
      },
    });

    if (mediaBtn) {
      mediaBtn.addEventListener("click", () => mediaFileInput.click());
    }

    // ---------- Duração ----------
    if (durationBtn && durationPanel) {
      durationBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        toggleDurationPanel();
      });
      durationPanel.addEventListener("click", (e) => {
        const btn = e.target.closest(".composer-duration-opt");
        if (!btn) return;
        durationPanel.querySelectorAll(".composer-duration-opt").forEach((b) => b.classList.remove("selected"));
        btn.classList.add("selected");
        durationInput.value = btn.dataset.minutes;
        durationLabel.textContent = "Some em " + btn.textContent.toLowerCase();
        closeDurationPanel();
      });
    }

    form.addEventListener("submit", () => {
      postBtn.disabled = true;
      postBtn.textContent = "Publicando…";
    });

    updatePostState();
  });
})();
