(function () {
  const scriptTag = document.currentScript;
  const POLL_MS = 4000;
  const INBOX_POLL_MS = 5000;

  function setBadge(el, count) {
    if (!el) return;
    if (count > 0) {
      el.textContent = count > 99 ? "99+" : String(count);
      el.hidden = false;
    } else {
      el.hidden = true;
    }
  }

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, (c) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
    }[c]));
  }

  document.addEventListener("DOMContentLoaded", () => {
    const countUrl = scriptTag && scriptTag.dataset.chatCountUrl;

    // Mesma ideia do notifications.js: detecta quando a contagem de não lidas
    // sobe para tocar o aviso sonoro em qualquer página, não só dentro da
    // conversa aberta.
    let lastUnreadCount = null;

    function pollBadge() {
      if (!countUrl) return;
      fetch(countUrl, { headers: { "X-Requested-With": "fetch" } })
        .then((res) => (res.ok ? res.json() : null))
        .then((data) => {
          if (!data) return;
          setBadge(document.getElementById("chat-badge"), data.unread);
          setBadge(document.getElementById("chat-badge-sidebar"), data.unread);
          if (lastUnreadCount !== null && data.unread > lastUnreadCount && window.driqySettings) {
            window.driqySettings.playMessageSound();
          }
          lastUnreadCount = data.unread;
        })
        .catch(() => {});
    }

    if (countUrl) {
      pollBadge();
      setInterval(pollBadge, POLL_MS);
    }

    // ---------- Thread de conversa (mensagens em tempo real) ----------
    const threadEl = document.getElementById("chat-thread");
    if (threadEl) {
      const pollUrl = threadEl.dataset.pollUrl;
      const sendUrl = threadEl.dataset.sendUrl;
      const form = document.getElementById("chat-form");
      const input = document.getElementById("chat-input");
      let lastId = parseInt(threadEl.dataset.lastId || "0", 10);

      function scrollToBottom() {
        threadEl.scrollTop = threadEl.scrollHeight;
      }
      scrollToBottom();

      function bubbleHtml(m) {
        return (
          '<div class="chat-bubble-row ' + (m.mine ? "mine" : "") + '" data-msg-id="' + m.id + '">' +
          '<div class="chat-bubble">' + escapeHtml(m.content) + '</div>' +
          '<div class="chat-bubble-meta">' + m.created_at + '</div>' +
          '</div>'
        );
      }

      function pollMessages() {
        fetch(pollUrl + "?since_id=" + lastId, { headers: { "X-Requested-With": "fetch" } })
          .then((res) => (res.ok ? res.json() : null))
          .then((data) => {
            if (!data || !data.messages || !data.messages.length) return;
            const wasNearBottom = threadEl.scrollHeight - threadEl.scrollTop - threadEl.clientHeight < 120;
            let receivedNew = false;
            data.messages.forEach((m) => {
              if (m.id > lastId) lastId = m.id;
              if (!m.mine) receivedNew = true;
              threadEl.insertAdjacentHTML("beforeend", bubbleHtml(m));
            });
            if (wasNearBottom) scrollToBottom();
            if (receivedNew && window.driqySettings) window.driqySettings.playMessageSound();
          })
          .catch(() => {});
      }

      if (pollUrl) setInterval(pollMessages, POLL_MS);

      if (form && input && sendUrl) {
        form.addEventListener("submit", (event) => {
          event.preventDefault();
          const content = input.value.trim();
          if (!content) return;
          input.disabled = true;
          fetch(sendUrl, {
            method: "POST",
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
              "X-Requested-With": "fetch",
            },
            body: "content=" + encodeURIComponent(content),
          })
            .then((res) => (res.ok ? res.json() : null))
            .then((data) => {
              if (data && data.message) {
                lastId = Math.max(lastId, data.message.id);
                threadEl.insertAdjacentHTML("beforeend", bubbleHtml(data.message));
                scrollToBottom();
                input.value = "";
              }
            })
            .catch(() => {})
            .finally(() => {
              input.disabled = false;
              input.focus();
            });
        });
      }
    }

    // ---------- Caixa de entrada: prévias e contadores ao vivo ----------
    const inboxList = document.getElementById("chat-inbox-list");
    if (inboxList) {
      const updatesUrl = inboxList.dataset.updatesUrl;
      if (updatesUrl) {
        setInterval(() => {
          fetch(updatesUrl, { headers: { "X-Requested-With": "fetch" } })
            .then((res) => (res.ok ? res.json() : null))
            .then((data) => {
              if (!data) return;
              const conversations = data.conversations || [];
              if (!conversations.length) return;

              const emptyState = document.getElementById("chat-inbox-empty-state");
              if (emptyState) emptyState.remove();

              const template = document.createElement("template");
              conversations.forEach((c) => {
                const row = inboxList.querySelector('[data-partner-id="' + c.partner_id + '"]');
                if (row) {
                  const preview = row.querySelector(".conv-preview");
                  const meta = row.querySelector(".conv-meta");
                  const unreadBadge = row.querySelector(".notif-badge");
                  if (preview) preview.textContent = c.last_content;
                  if (meta) meta.textContent = c.last_created_at;
                  if (unreadBadge) setBadge(unreadBadge, c.unread);
                  row.classList.toggle("conv-unread", c.unread > 0);
                } else if (c.html) {
                  template.innerHTML = c.html.trim();
                  const newRow = template.content.firstElementChild;
                  if (newRow) inboxList.insertBefore(newRow, inboxList.firstChild);
                }
              });
            })
            .catch(() => {});
        }, INBOX_POLL_MS);
      }
    }
  });
})();
