/*
 * Carrossel de mídia em tela cheia ("lightbox"). Abre quando a pessoa clica
 * em um item da grade de fotos/vídeos de um post com mais de uma mídia
 * (ver .media-grid em _post_card.html). Mostra TODAS as mídias do post,
 * mesmo as que não aparecem destacadas na grade, e deixa rolar para os
 * lados (arrastando, com a roda do mouse, ou pelas setas) para ver as
 * outras.
 */
(function () {
  let overlay, track, counterEl, closeBtn, prevBtn, nextBtn;
  let items = [];
  let ready = false;

  function buildOverlay() {
    overlay = document.createElement("div");
    overlay.className = "media-lightbox";
    overlay.setAttribute("aria-hidden", "true");
    overlay.innerHTML = `
      <button type="button" class="media-lightbox-close" aria-label="Fechar">✕</button>
      <button type="button" class="media-lightbox-nav media-lightbox-prev" aria-label="Item anterior">‹</button>
      <div class="media-lightbox-track"></div>
      <button type="button" class="media-lightbox-nav media-lightbox-next" aria-label="Próximo item">›</button>
      <div class="media-lightbox-counter"></div>
    `;
    document.body.appendChild(overlay);

    track = overlay.querySelector(".media-lightbox-track");
    counterEl = overlay.querySelector(".media-lightbox-counter");
    closeBtn = overlay.querySelector(".media-lightbox-close");
    prevBtn = overlay.querySelector(".media-lightbox-prev");
    nextBtn = overlay.querySelector(".media-lightbox-next");

    closeBtn.addEventListener("click", close);
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) close();
    });
    prevBtn.addEventListener("click", () => goTo(currentIndex() - 1));
    nextBtn.addEventListener("click", () => goTo(currentIndex() + 1));

    track.addEventListener("scroll", () => {
      window.requestAnimationFrame(updateCounter);
    });

    document.addEventListener("keydown", (e) => {
      if (overlay.getAttribute("aria-hidden") === "true") return;
      if (e.key === "Escape") close();
      if (e.key === "ArrowRight") goTo(currentIndex() + 1);
      if (e.key === "ArrowLeft") goTo(currentIndex() - 1);
    });

    ready = true;
  }

  function currentIndex() {
    if (!track.children.length) return 0;
    const slideWidth = track.clientWidth;
    return Math.round(track.scrollLeft / slideWidth);
  }

  function updateCounter() {
    const idx = Math.min(items.length - 1, Math.max(0, currentIndex()));
    counterEl.textContent = `${idx + 1} / ${items.length}`;
    prevBtn.disabled = idx <= 0;
    nextBtn.disabled = idx >= items.length - 1;
  }

  function goTo(index) {
    const clamped = Math.min(items.length - 1, Math.max(0, index));
    track.scrollTo({ left: clamped * track.clientWidth, behavior: "smooth" });
  }

  function pauseAllVideos() {
    track.querySelectorAll("video").forEach((v) => v.pause());
  }

  function render(startIndex) {
    track.innerHTML = "";
    items.forEach((item) => {
      const slide = document.createElement("div");
      slide.className = "media-lightbox-slide";
      if (item.type === "video") {
        const video = document.createElement("video");
        video.src = item.url;
        video.controls = true;
        video.playsInline = true;
        slide.appendChild(video);
      } else {
        const img = document.createElement("img");
        img.src = item.url;
        img.alt = "Mídia em tela cheia";
        slide.appendChild(img);
      }
      track.appendChild(slide);
    });

    // posiciona sem animação na mídia inicial antes de exibir
    track.style.scrollBehavior = "auto";
    track.scrollLeft = startIndex * track.clientWidth;
    requestAnimationFrame(() => {
      track.style.scrollBehavior = "";
      updateCounter();
    });
  }

  function open(mediaItems, startIndex) {
    if (!ready) buildOverlay();
    items = mediaItems;
    overlay.setAttribute("aria-hidden", "false");
    document.body.classList.add("media-lightbox-open");
    render(startIndex || 0);
  }

  function close() {
    if (!ready) return;
    pauseAllVideos();
    overlay.setAttribute("aria-hidden", "true");
    document.body.classList.remove("media-lightbox-open");
    track.innerHTML = "";
  }

  document.addEventListener("click", (event) => {
    const btn = event.target.closest(".media-grid-item");
    if (!btn) return;
    const grid = btn.closest(".media-grid");
    const dataScript = grid && grid.parentElement && grid.parentElement.querySelector(".media-gallery-data");
    if (!dataScript) return;

    let parsed;
    try {
      parsed = JSON.parse(dataScript.textContent);
    } catch (e) {
      return;
    }
    const index = parseInt(btn.dataset.index, 10) || 0;
    open(parsed, index);
  });

  window.driqyMediaLightbox = { open, close };
})();
