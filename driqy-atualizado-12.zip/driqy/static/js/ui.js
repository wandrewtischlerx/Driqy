(function () {
  document.addEventListener("DOMContentLoaded", () => {
    // ---------- Sidebar (menu no canto superior esquerdo) ----------
    const sidebarToggle = document.getElementById("sidebar-toggle");
    const sidebar = document.getElementById("sidebar");
    const sidebarClose = document.getElementById("sidebar-close");
    const sidebarOverlay = document.getElementById("sidebar-overlay");

    if (sidebarToggle && sidebar && sidebarOverlay) {
      const openSidebar = () => {
        sidebar.classList.add("open");
        sidebarOverlay.classList.add("open");
        sidebar.setAttribute("aria-hidden", "false");
        sidebarToggle.setAttribute("aria-expanded", "true");
        document.body.style.overflow = "hidden";
      };

      const closeSidebar = () => {
        sidebar.classList.remove("open");
        sidebarOverlay.classList.remove("open");
        sidebar.setAttribute("aria-hidden", "true");
        sidebarToggle.setAttribute("aria-expanded", "false");
        document.body.style.overflow = "";
      };

      sidebarToggle.addEventListener("click", () => {
        if (sidebar.classList.contains("open")) {
          closeSidebar();
        } else {
          openSidebar();
        }
      });

      if (sidebarClose) {
        sidebarClose.addEventListener("click", closeSidebar);
      }

      sidebarOverlay.addEventListener("click", closeSidebar);

      document.addEventListener("keydown", (event) => {
        if (event.key === "Escape" && sidebar.classList.contains("open")) {
          closeSidebar();
        }
      });

      sidebar.querySelectorAll(".sidebar-nav a").forEach((link) => {
        link.addEventListener("click", closeSidebar);
      });
    }
  });
})();
