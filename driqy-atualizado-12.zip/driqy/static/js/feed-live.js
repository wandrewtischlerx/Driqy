(function () {
  const POLL_MS = 6000;

  document.addEventListener("DOMContentLoaded", () => {
    const list = document.getElementById("feed-list");
    if (!list) return;

    const liveUrl = list.dataset.liveUrl;
    if (!liveUrl) return; // só a primeira página do feed atualiza sozinha

    let lastId = parseInt(list.dataset.lastId || "0", 10);
    let inFlight = false;

    function poll() {
      if (inFlight) return;
      inFlight = true;
      fetch(liveUrl + "?since_id=" + lastId, { headers: { "X-Requested-With": "fetch" } })
        .then((res) => (res.ok ? res.json() : null))
        .then((data) => {
          if (!data || !data.posts || !data.posts.length) return;

          const emptyState = document.getElementById("feed-empty-state");
          if (emptyState) emptyState.remove();

          const template = document.createElement("template");
          // vêm do mais antigo pro mais novo — insere cada um no topo, nessa
          // ordem, pra terminar com o mais novo por cima
          data.posts.forEach((html) => {
            template.innerHTML = html.trim();
            const card = template.content.firstElementChild;
            if (!card) return;
            list.insertBefore(card, list.firstChild);
            card.classList.add("post-just-arrived");
            if (window.driqyCountdown) window.driqyCountdown.registerCard(card);
            if (window.driqyCountdown) window.driqyCountdown.tickElapsedLabels();
            if (window.driqyVideoAutoplay) window.driqyVideoAutoplay.setupCard(card);
          });

          if (data.last_id) lastId = data.last_id;
          list.dataset.lastId = String(lastId);
        })
        .catch(() => {})
        .finally(() => {
          inFlight = false;
        });
    }

    setInterval(poll, POLL_MS);
  });
})();
