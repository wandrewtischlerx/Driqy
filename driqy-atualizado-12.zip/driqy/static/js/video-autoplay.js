(function () {
  function setMuteIcon(btn, muted) {
    const iconMuted = btn.querySelector(".icon-muted");
    const iconUnmuted = btn.querySelector(".icon-unmuted");
    if (iconMuted) iconMuted.hidden = !muted;
    if (iconUnmuted) iconUnmuted.hidden = muted;
    btn.dataset.muted = String(muted);
    const label = muted ? "Ativar som" : "Desativar som";
    btn.setAttribute("aria-label", label);
    btn.setAttribute("title", label);
  }

  function setupVideoWrap(wrap) {
    if (!wrap || wrap.dataset.autoplayReady) return;
    const video = wrap.querySelector("video.feed-video");
    const btn = wrap.querySelector(".video-mute-toggle");
    if (!video) return;
    wrap.dataset.autoplayReady = "1";

    video.muted = true;
    video.defaultMuted = true;
    setMuteIcon(btn, true);

    if (btn) {
      btn.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        video.muted = !video.muted;
        setMuteIcon(btn, video.muted);
      });
    }

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && entry.intersectionRatio >= 0.5) {
            const playPromise = video.play();
            if (playPromise && playPromise.catch) playPromise.catch(() => {});
          } else {
            video.pause();
          }
        });
      },
      { threshold: [0, 0.5, 1] }
    );
    observer.observe(video);
    wrap._autoplayObserver = observer;
  }

  function setupCard(scope) {
    (scope || document).querySelectorAll(".video-wrap").forEach(setupVideoWrap);
  }

  window.driqyVideoAutoplay = { setupCard, setupVideoWrap };

  document.addEventListener("DOMContentLoaded", () => setupCard(document));
})();
